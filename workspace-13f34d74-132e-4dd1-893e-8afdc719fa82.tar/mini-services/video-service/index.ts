/**
 * صحتي | Sehati — WebRTC Signaling Mini-Service
 *
 * Independent Bun + TypeScript + Socket.io server that brokers 1-to-1
 * video consultations between a patient and a doctor.
 *
 * - Port: 3004 (hardcoded, NOT from env)
 * - Socket.io path: "/" (REQUIRED — Caddy uses this to route)
 * - Frontend connects via: io("/?XTransformPort=3004")
 *
 * Signaling protocol (socket.io events):
 *   Client → Server : join-room, offer, answer, ice-candidate, toggle-media, end-call
 *   Server → Client : peer-joined, peer-ready, offer, answer, ice-candidate,
 *                     toggle-media, end-call, peer-left, error
 */

import { createServer, type IncomingMessage, type ServerResponse } from 'http'
import { Server, type Socket } from 'socket.io'

// --- Configuration ---------------------------------------------------------

const PORT = 3004 // Hardcoded per spec — DO NOT change.

// --- Peer registry ---------------------------------------------------------

type Role = 'patient' | 'doctor'

interface PeerInfo {
  roomId: string
  role: Role
  name: string
}

/** socket.id → peer info */
const peers = new Map<string, PeerInfo>()

// --- HTTP + Socket.io server setup ----------------------------------------

const httpServer = createServer()

const io = new Server(httpServer, {
  // DO NOT change the path — Caddy uses this to forward to the correct port.
  path: '/',
  cors: {
    origin: '*',
    methods: ['GET', 'POST'],
  },
  pingTimeout: 60000,
  pingInterval: 25000,
})

/**
 * With `path: '/'`, engine.io intercepts ALL HTTP requests (every URL starts
 * with '/'). To expose a `/health` endpoint, we wrap engine.io's request
 * listener and handle `/health` ourselves, delegating everything else to
 * engine.io (socket.io polling / websocket upgrade).
 */
const engineRequestListeners = httpServer
  .listeners('request')
  .slice(0) as Array<(req: IncomingMessage, res: ServerResponse) => void>

httpServer.removeAllListeners('request')

httpServer.on('request', (req, res) => {
  // Health check endpoint (HTTP GET).
  if (req.url === '/health' || req.url === '/health/') {
    res.writeHead(200, { 'Content-Type': 'application/json' })
    res.end(
      JSON.stringify({
        ok: true,
        service: 'sehati-video-service',
        port: PORT,
      }),
    )
    return
  }

  // Delegate everything else to engine.io (socket.io).
  for (const listener of engineRequestListeners) {
    listener.call(httpServer, req, res)
  }
})

// Surface any uncaught errors so they show in the log instead of silently
// killing the process.
process.on('uncaughtException', (err) => {
  console.error('[video-service] UNCAUGHT EXCEPTION:', err)
})
process.on('unhandledRejection', (err) => {
  console.error('[video-service] UNHANDLED REJECTION:', err)
})

// --- Signaling event handlers ---------------------------------------------

io.on('connection', (socket: Socket) => {
  console.log(`[video-service] socket connected: ${socket.id}`)

  /**
   * join-room — a peer joins a consultation room.
   * payload: { roomId, role, name }
   */
  socket.on(
    'join-room',
    (payload: { roomId?: string; role?: Role; name?: string }) => {
      if (!payload || !payload.roomId || !payload.role || !payload.name) {
        socket.emit('error', {
          message: 'Invalid join-room payload (requires roomId, role, name)',
        })
        return
      }

      const { roomId, role, name } = payload

      // Store peer info.
      peers.set(socket.id, { roomId, role, name })

      // Join the socket.io room.
      void socket.join(roomId)

      // Broadcast to others in the room that a new peer joined.
      socket.to(roomId).emit('peer-joined', {
        socketId: socket.id,
        role,
        name,
      })

      // If a peer is already in the room, tell the joiner they should
      // initiate the WebRTC offer to the existing peer.
      const existingPeer = Array.from(peers.entries()).find(
        ([sid, info]) => info.roomId === roomId && sid !== socket.id,
      )

      if (existingPeer) {
        const [, info] = existingPeer
        socket.emit('peer-ready', {
          socketId: existingPeer[0],
          role: info.role,
          name: info.name,
        })
      }

      console.log(
        `[video-service] ${role} "${name}" joined room ${roomId} (socket ${socket.id})` +
          (existingPeer ? ` — peer-ready emitted` : ' — waiting for peer'),
      )
    },
  )

  /**
   * offer — forward a WebRTC offer SDP to the target peer.
   * payload: { to, sdp }
   */
  socket.on('offer', (payload: { to?: string; sdp?: unknown }) => {
    if (!payload || !payload.to) return
    io.to(payload.to).emit('offer', {
      from: socket.id,
      sdp: payload.sdp,
    })
  })

  /**
   * answer — forward a WebRTC answer SDP to the target peer.
   * payload: { to, sdp }
   */
  socket.on('answer', (payload: { to?: string; sdp?: unknown }) => {
    if (!payload || !payload.to) return
    io.to(payload.to).emit('answer', {
      from: socket.id,
      sdp: payload.sdp,
    })
  })

  /**
   * ice-candidate — forward an ICE candidate to the target peer.
   * payload: { to, candidate }
   */
  socket.on(
    'ice-candidate',
    (payload: { to?: string; candidate?: unknown }) => {
      if (!payload || !payload.to) return
      io.to(payload.to).emit('ice-candidate', {
        from: socket.id,
        candidate: payload.candidate,
      })
    },
  )

  /**
   * toggle-media — broadcast camera/mic state to the room (except sender)
   * so the other peer can update the UI (mute / camera-off indicator).
   * payload: { video, audio }
   */
  socket.on('toggle-media', (payload: { video?: boolean; audio?: boolean }) => {
    const peer = peers.get(socket.id)
    if (!peer || !payload) return
    socket.to(peer.roomId).emit('toggle-media', {
      socketId: socket.id,
      video: Boolean(payload.video),
      audio: Boolean(payload.audio),
    })
  })

  /**
   * end-call — broadcast to the room (except sender) and leave the room.
   * Per spec: only broadcasts and leaves; the peer entry stays in the
   * registry so that a subsequent `disconnect` still emits `peer-left`.
   */
  socket.on('end-call', () => {
    const peer = peers.get(socket.id)
    if (!peer) return
    socket.to(peer.roomId).emit('end-call', { from: socket.id })
    void socket.leave(peer.roomId)
    console.log(
      `[video-service] ${peer.role} "${peer.name}" ended call in room ${peer.roomId}`,
    )
  })

  /**
   * disconnect — remove peer from registry and notify the room.
   */
  socket.on('disconnect', () => {
    const peer = peers.get(socket.id)
    if (peer) {
      socket.to(peer.roomId).emit('peer-left', {
        socketId: socket.id,
        name: peer.name,
      })
      peers.delete(socket.id)
      console.log(
        `[video-service] ${peer.role} "${peer.name}" disconnected from room ${peer.roomId}`,
      )
    } else {
      console.log(`[video-service] socket ${socket.id} disconnected`)
    }
  })

  socket.on('error', (err: unknown) => {
    console.error(`[video-service] socket error (${socket.id}):`, err)
  })
})

// --- Start server ----------------------------------------------------------

httpServer.listen(PORT, () => {
  console.log(`Sehati video service listening on :${PORT}`)
})

// --- Graceful shutdown -----------------------------------------------------

const shutdown = (signal: string) => {
  console.log(`[video-service] received ${signal}, shutting down...`)
  io.close(() => {
    console.log('[video-service] socket.io server closed')
    httpServer.close(() => {
      console.log('[video-service] http server closed')
      process.exit(0)
    })
  })
}

process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('SIGINT', () => shutdown('SIGINT'))
