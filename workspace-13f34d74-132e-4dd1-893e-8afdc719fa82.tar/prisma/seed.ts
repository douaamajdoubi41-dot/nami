// Seed script for صحتي | Sehati — realistic Moroccan hospitals & doctors.
// Run with: bun run prisma/seed.ts  (or via the /api/seed endpoint at runtime)

import { PrismaClient } from "@prisma/client";
import { hashPassword } from "../src/lib/auth";

const db = new PrismaClient();

const MOROCCAN_CITIES = [
  "Casablanca",
  "Rabat",
  "Fès",
  "Marrakech",
  "Tanger",
  "Agadir",
  "Meknès",
  "Oujda",
];

interface SeedHospital {
  name: string;
  nameAr: string;
  type: "PUBLIC" | "PRIVATE" | "CLINIC";
  city: string;
  address: string;
  lat: number;
  lng: number;
  phone: string;
  open24h: boolean;
  emergency: boolean;
  ambulance: boolean;
  rating: number;
  images: string[];
  services: string[];
  description: string;
  doctors: SeedDoctor[];
}

interface SeedDoctor {
  name: string;
  nameAr: string;
  specialty: string;
  specialtyAr: string;
  consultationPrice: number;
  rating: number;
  availableToday: boolean;
  videoEnabled: boolean;
  bio: string;
}

const HOSPITALS: SeedHospital[] = [
  {
    name: "CHU Ibn Rochd",
    nameAr: "مستشفى ابن رشد الجامعي",
    type: "PUBLIC",
    city: "Casablanca",
    address: "Bd Tarik Ibn Ziad, Casablanca",
    lat: 33.5731,
    lng: -7.5898,
    phone: "+212522266989",
    open24h: true,
    emergency: true,
    ambulance: true,
    rating: 4.1,
    images: [],
    services: [
      "Émergences",
      "Cardiologie",
      "Pédiatrie",
      "Chirurgie",
      "Maternité",
      "Radiologie",
    ],
    description:
      "Grand centre hospitalier universitaire public de Casablanca, ouvert 24/24 avec urgences et ambulance.",
    doctors: [
      {
        name: "Dr. Karim Benjelloun",
        nameAr: "د. كريم بنجلون",
        specialty: "Cardiology",
        specialtyAr: "أمراض القلب",
        consultationPrice: 250,
        rating: 4.6,
        availableToday: true,
        videoEnabled: true,
        bio: "Cardiologue au CHU Ibn Rochd, 12 ans d'expérience.",
      },
      {
        name: "Dr. Salma El Fassi",
        nameAr: "د. سلمة الفاسي",
        specialty: "Pediatrics",
        specialtyAr: "طب الأطفال",
        consultationPrice: 200,
        rating: 4.8,
        availableToday: true,
        videoEnabled: true,
        bio: "Pédiatre, spécialiste des urgences infantiles.",
      },
      {
        name: "Dr. Youssef Amrani",
        nameAr: "د. يوسف العمراني",
        specialty: "General",
        specialtyAr: "طب عام",
        consultationPrice: 150,
        rating: 4.3,
        availableToday: true,
        videoEnabled: true,
        bio: "Médecin généraliste, consultations du jour.",
      },
    ],
  },
  {
    name: "Clinique Pasteur",
    nameAr: "مصحة باستور",
    type: "CLINIC",
    city: "Casablanca",
    address: "Rue Mohammed Diouri, Casablanca",
    lat: 33.5889,
    lng: -7.6325,
    phone: "+212522220220",
    open24h: false,
    emergency: false,
    ambulance: true,
    rating: 4.5,
    images: [],
    services: ["Chirurgie", "Maternité", "Imagerie", "Labo"],
    description: "Clinique privée moderne au cœur de Casablanca.",
    doctors: [
      {
        name: "Dr. Nadia Berrada",
        nameAr: "د. نادية برادة",
        specialty: "Dermatology",
        specialtyAr: "الجلد",
        consultationPrice: 400,
        rating: 4.7,
        availableToday: true,
        videoEnabled: true,
        bio: "Dermatologue, traitements laser et esthétiques.",
      },
      {
        name: "Dr. Hicham Tazi",
        nameAr: "د. هشام التازي",
        specialty: "Orthopedics",
        specialtyAr: "العظام",
        consultationPrice: 350,
        rating: 4.5,
        availableToday: false,
        videoEnabled: false,
        bio: "Chirurgien orthopédiste.",
      },
    ],
  },
  {
    name: "Hôpital Cheikh Zaid",
    nameAr: "مستشفى الشيخ زايد",
    type: "PRIVATE",
    city: "Rabat",
    address: "Hay Riad, Rabat",
    lat: 33.975,
    lng: -6.84,
    phone: "+212537567000",
    open24h: true,
    emergency: true,
    ambulance: true,
    rating: 4.7,
    images: [],
    services: [
      "Toutes spécialités",
      "Émergences",
      "Chirurgie",
      "Imagerie",
      "Maternité",
    ],
    description:
      "Hôpital privé de référence à Rabat, ouvert 24/24, équipements de pointe.",
    doctors: [
      {
        name: "Dr. Fatima Zahra Lahlou",
        nameAr: "د. فاطمة الزهراء لahlou",
        specialty: "Gynecology",
        specialtyAr: "النساء والتوليد",
        consultationPrice: 450,
        rating: 4.9,
        availableToday: true,
        videoEnabled: true,
        bio: "Gynécologue-obstétricienne, suivi de grossesse.",
      },
      {
        name: "Dr. Omar Sebti",
        nameAr: "د. عمر السبتي",
        specialty: "Neurology",
        specialtyAr: "الأعصاب",
        consultationPrice: 500,
        rating: 4.6,
        availableToday: true,
        videoEnabled: false,
        bio: "Neurologue, spécialiste migraines et épilepsie.",
      },
      {
        name: "Dr. Leila Idrissi",
        nameAr: "د. ليلى الإدريسي",
        specialty: "Ophthalmology",
        specialtyAr: "العيون",
        consultationPrice: 380,
        rating: 4.5,
        availableToday: true,
        videoEnabled: true,
        bio: "Ophtalmologue, chirurgie réfractive.",
      },
    ],
  },
  {
    name: "Hôpital Universitaire Hassan II",
    nameAr: "مستشفى الحسن الثاني الجامعي",
    type: "PUBLIC",
    city: "Fès",
    address: "Route Sidi Harazem, Fès",
    lat: 34.0331,
    lng: -5.0003,
    phone: "+212535619000",
    open24h: true,
    emergency: true,
    ambulance: true,
    rating: 4.0,
    images: [],
    services: ["Émergences", "Chirurgie", "Cardiologie", "Pédiatrie", "Maternité"],
    description: "CHU public de Fès, urgences 24/24.",
    doctors: [
      {
        name: "Dr. Mehdi Alaoui",
        nameAr: "د. مهدي العلوي",
        specialty: "Cardiology",
        specialtyAr: "أمراض القلب",
        consultationPrice: 200,
        rating: 4.4,
        availableToday: true,
        videoEnabled: true,
        bio: "Cardiologue interventionnel.",
      },
      {
        name: "Dr. Khadija Bennani",
        nameAr: "د. خديجة بناني",
        specialty: "Pediatrics",
        specialtyAr: "طب الأطفال",
        consultationPrice: 180,
        rating: 4.7,
        availableToday: true,
        videoEnabled: true,
        bio: "Pédiatre, néonatologie.",
      },
    ],
  },
  {
    name: "Clinique Al Akhawayn",
    nameAr: "مصحة الأخوين",
    type: "PRIVATE",
    city: "Marrakech",
    address: "Av. Mohammed VI, Marrakech",
    lat: 31.6295,
    lng: -7.9811,
    phone: "+212524335000",
    open24h: false,
    emergency: true,
    ambulance: true,
    rating: 4.4,
    images: [],
    services: ["Chirurgie", "Maternité", "Esthétique", "Imagerie"],
    description: "Clinique privée de Marrakech, soins premium.",
    doctors: [
      {
        name: "Dr. Rachid Ouazzani",
        nameAr: "د. رشيد الوزاني",
        specialty: "Dentistry",
        specialtyAr: "الأسنان",
        consultationPrice: 300,
        rating: 4.6,
        availableToday: true,
        videoEnabled: false,
        bio: "Chirurgien-dentiste, implantologie.",
      },
      {
        name: "Dr. Hanae Sefrioui",
        nameAr: "د. هناء السفريوي",
        specialty: "Dermatology",
        specialtyAr: "الجلد",
        consultationPrice: 420,
        rating: 4.8,
        availableToday: true,
        videoEnabled: true,
        bio: "Dermatologue, cosmétique.",
      },
    ],
  },
  {
    name: "Hôpital Mohammed V",
    nameAr: "مستشفى محمد الخامس",
    type: "PUBLIC",
    city: "Tanger",
    address: "Av. Mohammed V, Tanger",
    lat: 35.7595,
    lng: -5.834,
    phone: "+212539932000",
    open24h: true,
    emergency: true,
    ambulance: true,
    rating: 3.9,
    images: [],
    services: ["Émergences", "Chirurgie", "Pédiatrie", "Maternité"],
    description: "Hôpital public de Tanger, urgences 24/24.",
    doctors: [
      {
        name: "Dr. Tarik Naciri",
        nameAr: "د. طارق الناصري",
        specialty: "ENT",
        specialtyAr: "الأنف والأذن والحنجرة",
        consultationPrice: 220,
        rating: 4.2,
        availableToday: true,
        videoEnabled: true,
        bio: "ORL, chirurgie endoscopique.",
      },
      {
        name: "Dr. Imane Cherkaoui",
        nameAr: "د. إيمان الشرقاوي",
        specialty: "Psychiatry",
        specialtyAr: "الطب النفسي",
        consultationPrice: 350,
        rating: 4.5,
        availableToday: false,
        videoEnabled: true,
        bio: "Psychiatre, thérapie par visio.",
      },
    ],
  },
  {
    name: "Clinique Agadir Souss",
    nameAr: "مصحة أكادير سوس",
    type: "CLINIC",
    city: "Agadir",
    address: "Quartie Talborjt, Agadir",
    lat: 30.4278,
    lng: -9.5981,
    phone: "+212528841000",
    open24h: false,
    emergency: false,
    ambulance: true,
    rating: 4.3,
    images: [],
    services: ["Chirurgie", "Maternité", "Imagerie", "Labo"],
    description: "Clinique d'Agadir, soins généraux.",
    doctors: [
      {
        name: "Dr. Soufiane El Ghazouani",
        nameAr: "د. سفيان الغزواني",
        specialty: "Orthopedics",
        specialtyAr: "العظام",
        consultationPrice: 320,
        rating: 4.4,
        availableToday: true,
        videoEnabled: true,
        bio: "Orthopédiste, traumatologie sportive.",
      },
      {
        name: "Dr. Meryem Bouhaddou",
        nameAr: "د. مريم بوحدو",
        specialty: "General",
        specialtyAr: "طب عام",
        consultationPrice: 160,
        rating: 4.6,
        availableToday: true,
        videoEnabled: true,
        bio: "Médecin généraliste, visioconsultations.",
      },
    ],
  },
  {
    name: "Pharmacie de Garde Centrale",
    nameAr: "صيدلية الحراسة المركزية",
    type: "CLINIC",
    city: "Rabat",
    address: "Av. Allal Ben Abdellah, Rabat",
    lat: 34.0209,
    lng: -6.8416,
    phone: "+212537700700",
    open24h: true,
    emergency: false,
    ambulance: false,
    rating: 4.2,
    images: [],
    services: ["Pharmacie 24/24", "Conseil pharmaceutique"],
    description: "Pharmacie de garde centrale, ouverte jour et nuit.",
    doctors: [],
  },
];

const AVAILABILITY = JSON.stringify([
  { day: "MON", start: "09:00", end: "17:00" },
  { day: "TUE", start: "09:00", end: "17:00" },
  { day: "WED", start: "09:00", end: "17:00" },
  { day: "THU", start: "09:00", end: "17:00" },
  { day: "FRI", start: "09:00", end: "13:00" },
  { day: "SAT", start: "09:00", end: "13:00" },
]);

async function main() {
  console.log("🌱 Seeding Sehati database…");

  // Demo patient account (password: "patient123")
  await db.user.upsert({
    where: { email: "patient@sehati.ma" },
    update: {},
    create: {
      email: "patient@sehati.ma",
      password: hashPassword("patient123"),
      name: "Yassine Patient",
      phone: "+212600000000",
      role: "PATIENT",
      language: "fr",
    },
  });

  // Demo hospital admin account (password: "hospital123") — attached to first hospital below.
  const existingAdmin = await db.user.findUnique({
    where: { email: "admin@chuibnrochd.ma" },
  });

  let firstHospitalId: string | null = null;

  for (const sh of HOSPITALS) {
    const hospital = await db.hospital.create({
      data: {
        name: sh.name,
        nameAr: sh.nameAr,
        nameEn: sh.name,
        type: sh.type,
        city: sh.city,
        address: sh.address,
        lat: sh.lat,
        lng: sh.lng,
        phone: sh.phone,
        open24h: sh.open24h,
        emergency: sh.emergency,
        ambulance: sh.ambulance,
        rating: sh.rating,
        images: JSON.stringify(sh.images),
        services: JSON.stringify(sh.services),
        description: sh.description,
        doctors: {
          create: sh.doctors.map((d) => ({
            name: d.name,
            nameAr: d.nameAr,
            specialty: d.specialty,
            specialtyAr: d.specialtyAr,
            consultationPrice: d.consultationPrice,
            rating: d.rating,
            availableToday: d.availableToday,
            videoEnabled: d.videoEnabled,
            bio: d.bio,
            availability: AVAILABILITY,
          })),
        },
      },
    });
    if (!firstHospitalId) firstHospitalId = hospital.id;
  }

  if (!existingAdmin && firstHospitalId) {
    await db.user.create({
      data: {
        email: "admin@chuibnrochd.ma",
        password: hashPassword("hospital123"),
        name: "Admin CHU Ibn Rochd",
        phone: "+212522000000",
        role: "HOSPITAL_ADMIN",
        language: "fr",
        hospitalId: firstHospitalId,
      },
    });
  }

  console.log(`✅ Seeded ${HOSPITALS.length} hospitals.`);
  console.log("   Demo patient: patient@sehati.ma / patient123");
  console.log("   Demo hospital admin: admin@chuibnrochd.ma / hospital123");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
