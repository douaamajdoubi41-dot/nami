"use client";

import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import type { Lang, View } from "@/lib/types";

interface AppState {
  // i18n (theme is handled by next-themes directly)
  lang: Lang;
  setLang: (l: Lang) => void;

  // navigation (SPA view switching on the single `/` route)
  view: View;
  setView: (v: View) => void;

  // booking context (pass doctor/hospital into the booking flow)
  bookingDoctorId: string | null;
  bookingHospitalId: string | null;
  setBooking: (doctorId?: string | null, hospitalId?: string | null) => void;

  // video room context (when joining a video consult)
  activeRoomId: string | null;
  activeAppointmentId: string | null;
  setActiveVideo: (roomId: string, appointmentId: string) => void;
  clearActiveVideo: () => void;

  // location (for nearby sorting)
  userLat: number | null;
  userLng: number | null;
  locationEnabled: boolean;
  setLocation: (lat: number, lng: number) => void;
  clearLocation: () => void;

  // global search query (home page)
  search: string;
  setSearch: (s: string) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      lang: "fr",
      setLang: (l) => set({ lang: l }),

      view: "home",
      setView: (v) => {
        set({ view: v });
        if (typeof window !== "undefined") {
          window.scrollTo({ top: 0, behavior: "smooth" });
        }
      },

      bookingDoctorId: null,
      bookingHospitalId: null,
      setBooking: (doctorId, hospitalId) =>
        set({
          bookingDoctorId: doctorId ?? null,
          bookingHospitalId: hospitalId ?? null,
        }),

      activeRoomId: null,
      activeAppointmentId: null,
      setActiveVideo: (roomId, appointmentId) =>
        set({ activeRoomId: roomId, activeAppointmentId: appointmentId }),
      clearActiveVideo: () =>
        set({ activeRoomId: null, activeAppointmentId: null }),

      userLat: null,
      userLng: null,
      locationEnabled: false,
      setLocation: (lat, lng) =>
        set({ userLat: lat, userLng: lng, locationEnabled: true }),
      clearLocation: () =>
        set({ userLat: null, userLng: null, locationEnabled: false }),

      search: "",
      setSearch: (s) => set({ search: s }),
    }),
    {
      name: "sehati-store",
      storage: createJSONStorage(() => localStorage),
      skipHydration: true,
      partialize: (s) => ({
        lang: s.lang,
        userLat: s.userLat,
        userLng: s.userLng,
        locationEnabled: s.locationEnabled,
      }),
    },
  ),
);


