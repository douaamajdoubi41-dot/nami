"use client";

import { useState, ReactNode } from "react";
import { useAppStore } from "@/store/app-store";
import { useI18n } from "@/lib/i18n";
import { LanguageSwitcher } from "@/components/ui-custom/language-switcher";
import { useTheme } from "next-themes";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Home,
  Building2,
  Stethoscope,
  CalendarDays,
  Bot,
  Calculator,
  LayoutDashboard,
  User,
  LogIn,
  LogOut,
  Moon,
  Sun,
  Search,
  Menu,
  Heart,
  Phone,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { View } from "@/lib/types";

interface NavItem {
  view: View;
  icon: ReactNode;
  labelKey: string;
  patientOnly?: boolean;
  adminOnly?: boolean;
}

const NAV_ITEMS: NavItem[] = [
  { view: "home", icon: <Home className="h-5 w-5" />, labelKey: "nav.home" },
  {
    view: "hospitals",
    icon: <Building2 className="h-5 w-5" />,
    labelKey: "nav.hospitals",
  },
  {
    view: "doctors",
    icon: <Stethoscope className="h-5 w-5" />,
    labelKey: "nav.doctors",
  },
  {
    view: "appointments",
    icon: <CalendarDays className="h-5 w-5" />,
    labelKey: "nav.appointments",
    patientOnly: true,
  },
  {
    view: "assistant",
    icon: <Bot className="h-5 w-5" />,
    labelKey: "nav.assistant",
  },
  {
    view: "cost",
    icon: <Calculator className="h-5 w-5" />,
    labelKey: "nav.cost",
  },
  {
    view: "dashboard",
    icon: <LayoutDashboard className="h-5 w-5" />,
    labelKey: "nav.dashboard",
    adminOnly: true,
  },
];

export function AppShell({ children }: { children: ReactNode }) {
  const { t, lang } = useI18n();
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const { user, logout } = useAuth();
  const { theme, setTheme } = useTheme();
  const toggleTheme = () => setTheme(theme === "dark" ? "light" : "dark");
  const search = useAppStore((s) => s.search);
  const setSearch = useAppStore((s) => s.setSearch);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = NAV_ITEMS.filter((item) => {
    if (item.adminOnly && user?.role !== "HOSPITAL_ADMIN") return false;
    if (item.patientOnly && user && user.role !== "PATIENT") return false;
    return true;
  });

  const onLogout = async () => {
    await logout();
    setView("home");
  };

  const onSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setView("hospitals");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 border-b bg-background/90 backdrop-blur supports-[backdrop-filter]:bg-background/75">
        <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4">
          {/* Logo */}
          <button
            onClick={() => setView("home")}
            className="flex items-center gap-2 shrink-0"
            aria-label="Sehati home"
          >
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-sm">
              <Heart className="h-5 w-5 fill-white" />
            </span>
            <span className="hidden sm:flex flex-col leading-none">
              <span className="text-lg font-bold tracking-tight">
                {t("app.name")}
              </span>
              <span className="text-[10px] text-muted-foreground">
                {t("app.tagline")}
              </span>
            </span>
          </button>

          {/* Search (desktop) */}
          <form
            onSubmit={onSearchSubmit}
            className="relative hidden md:flex flex-1 max-w-md mx-2"
          >
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("home.searchPlaceholder")}
              className="pl-9 h-10 bg-muted/40 border-transparent focus-visible:bg-background"
            />
          </form>

          <div className="flex flex-1 md:flex-none items-center justify-end gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              aria-label="Toggle theme"
              className="h-9 w-9"
            >
              {theme === "light" ? (
                <Moon className="h-4 w-4" />
              ) : (
                <Sun className="h-4 w-4" />
              )}
            </Button>
            <LanguageSwitcher compact />
            {user ? (
              <>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setView("profile")}
                  className="hidden sm:flex gap-2"
                >
                  <User className="h-4 w-4" />
                  <span className="max-w-[120px] truncate">{user.name}</span>
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onLogout}
                  aria-label={t("nav.logout")}
                  className="h-9 w-9 sm:hidden"
                >
                  <LogOut className="h-4 w-4" />
                </Button>
              </>
            ) : (
              <Button
                size="sm"
                onClick={() => setView("auth")}
                className="gap-1.5"
              >
                <LogIn className="h-4 w-4" />
                <span className="hidden sm:inline">{t("nav.login")}</span>
              </Button>
            )}
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setMobileMenuOpen((v) => !v)}
              aria-label="Menu"
              className="h-9 w-9 lg:hidden"
            >
              {mobileMenuOpen ? (
                <X className="h-5 w-5" />
              ) : (
                <Menu className="h-5 w-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Desktop nav row */}
        <div className="hidden lg:block border-t bg-background/60">
          <nav className="mx-auto flex max-w-7xl items-center gap-1 px-4 h-12">
            {navItems.map((item) => (
              <button
                key={item.view}
                onClick={() => setView(item.view)}
                className={cn(
                  "flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors",
                  view === item.view
                    ? "bg-primary text-primary-foreground"
                    : "text-muted-foreground hover:text-foreground hover:bg-muted",
                )}
              >
                {item.icon}
                {t(item.labelKey)}
              </button>
            ))}
          </nav>
        </div>

        {/* Mobile dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t bg-background">
            <nav className="mx-auto grid max-w-7xl grid-cols-2 gap-1 p-3">
              {navItems.map((item) => (
                <button
                  key={item.view}
                  onClick={() => {
                    setView(item.view);
                    setMobileMenuOpen(false);
                  }}
                  className={cn(
                    "flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                    view === item.view
                      ? "bg-primary text-primary-foreground"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted",
                  )}
                >
                  {item.icon}
                  {t(item.labelKey)}
                </button>
              ))}
            </nav>
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="flex-1 w-full">
        <div className="mx-auto w-full max-w-7xl px-4 py-6 pb-28 lg:pb-10">
          {children}
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex items-center gap-2">
              <span className="grid h-8 w-8 place-items-center rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 text-white">
                <Heart className="h-4 w-4 fill-white" />
              </span>
              <div>
                <p className="text-sm font-semibold">{t("app.name")}</p>
                <p className="text-xs text-muted-foreground">
                  {t("app.tagline")} · Morocco 🇲🇦
                </p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <Phone className="h-3.5 w-3.5" /> Emergency: 150
              </span>
              <span>© {new Date().getFullYear()} Sehati</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Mobile bottom nav */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-40 border-t bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="grid grid-cols-5 h-16">
          {navItems.slice(0, 5).map((item) => (
            <button
              key={item.view}
              onClick={() => setView(item.view)}
              className={cn(
                "flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium transition-colors",
                view === item.view
                  ? "text-primary"
                  : "text-muted-foreground",
              )}
            >
              <span
                className={cn(
                  "grid place-items-center h-7 w-7 rounded-full transition-colors",
                  view === item.view && "bg-primary/10",
                )}
              >
                {item.icon}
              </span>
              {t(item.labelKey)}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}
