"use client";

import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Stethoscope,
  Search,
  MapPin,
  Video,
  Calendar,
} from "lucide-react";
import { fetchDoctors } from "@/lib/api-client";
import type { Doctor } from "@/lib/types";
import { RatingStars } from "@/components/ui-custom/rating-stars";
import { formatMAD } from "@/lib/format";

export function DoctorsSection() {
  const { t, lang } = useI18n();
  const setView = useAppStore((s) => s.setView);
  const setBooking = useAppStore((s) => s.setBooking);
  const bookingHospitalId = useAppStore((s) => s.bookingHospitalId);

  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [specialties, setSpecialties] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState("");
  const [specialty, setSpecialty] = useState("all");
  const [availableToday, setAvailableToday] = useState(false);
  const [videoOnly, setVideoOnly] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const r = await fetchDoctors({
        q,
        specialty: specialty === "all" ? undefined : specialty,
        availableToday,
        video: videoOnly,
        hospitalId: bookingHospitalId ?? undefined,
      });
      setDoctors(r.doctors);
      setSpecialties(r.specialties);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [specialty, availableToday, videoOnly, bookingHospitalId]);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Stethoscope className="h-6 w-6 text-emerald-600" />
          {t("doctors.title")}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          {loading ? "…" : `${doctors.length} ${t("hospitals.results")}`}
        </p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-3 md:p-4 space-y-3">
          <div className="flex gap-2 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground rtl:right-3 rtl:left-auto" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && load()}
                placeholder={t("home.searchPlaceholder")}
                className="pl-9 rtl:pl-3 rtl:pr-9"
              />
            </div>
            <Select value={specialty} onValueChange={setSpecialty}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder={t("doctors.filter.allSpecialties")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("doctors.filter.allSpecialties")}</SelectItem>
                {specialties.map((s) => (
                  <SelectItem key={s} value={s}>
                    {lang === "ar"
                      ? // try Arabic name
                        AR_SPECIALTIES[s] ?? s
                      : t(`specialty.${s}`, {}) !== `specialty.${s}`
                        ? t(`specialty.${s}`)
                        : s}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button onClick={load}>{t("common.search")}</Button>
          </div>
          <div className="flex flex-wrap gap-2">
            <FilterChip
              active={availableToday}
              onClick={() => setAvailableToday(!availableToday)}
              icon={<Calendar className="h-3.5 w-3.5" />}
              label={t("doctors.filter.availableToday")}
            />
            <FilterChip
              active={videoOnly}
              onClick={() => setVideoOnly(!videoOnly)}
              icon={<Video className="h-3.5 w-3.5" />}
              label={t("doctors.filter.video")}
            />
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {[0, 1, 2, 3, 4, 5].map((i) => (
            <Skeleton key={i} className="h-44 rounded-2xl" />
          ))}
        </div>
      ) : doctors.length === 0 ? (
        <Card>
          <CardContent className="p-10 text-center text-muted-foreground">
            {t("doctors.noResults")}
          </CardContent>
        </Card>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {doctors.map((d) => (
            <DoctorListItem
              key={d.id}
              doctor={d}
              onBook={() => {
                setBooking(d.id, d.hospitalId);
                setView("appointments");
              }}
            />
          ))}
        </div>
      )}
    </div>
  );
}

const AR_SPECIALTIES: Record<string, string> = {
  General: "طب عام",
  Cardiology: "أمراض القلب",
  Pediatrics: "طب الأطفال",
  Dermatology: "الجلد",
  Orthopedics: "العظام",
  Gynecology: "النساء والتوليد",
  Ophthalmology: "العيون",
  Neurology: "الأعصاب",
  Psychiatry: "الطب النفسي",
  Dentistry: "الأسنان",
  Radiology: "الأشعة",
  ENT: "الأنف والأذن والحنجرة",
};

function FilterChip({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border hover:bg-muted"
      }`}
    >
      {icon}
      {label}
    </button>
  );
}

function DoctorListItem({ doctor, onBook }: { doctor: Doctor; onBook: () => void }) {
  const { t, lang } = useI18n();
  const name = lang === "ar" && doctor.nameAr ? doctor.nameAr : doctor.name;
  const specialty =
    lang === "ar" && doctor.specialtyAr
      ? doctor.specialtyAr
      : AR_SPECIALTIES[doctor.specialty]
        ? lang === "ar"
          ? AR_SPECIALTIES[doctor.specialty]
          : t(`specialty.${doctor.specialty}`, {}) !==
            `specialty.${doctor.specialty}`
            ? t(`specialty.${doctor.specialty}`)
            : doctor.specialty
        : doctor.specialty;
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-semibold">
            {name.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold leading-tight truncate">{name}</h3>
            <p className="text-sm text-emerald-700 dark:text-emerald-400 font-medium truncate">
              {specialty}
            </p>
            {doctor.hospitalName && (
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5 truncate">
                <MapPin className="h-3 w-3" />
                {t("doctors.at")} {doctor.hospitalName}
                {doctor.hospitalCity ? `, ${doctor.hospitalCity}` : ""}
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center justify-between">
          <RatingStars value={doctor.rating} />
          <div className="flex items-center gap-1.5">
            {doctor.availableToday && (
              <Badge className="bg-emerald-600/10 text-emerald-700 dark:text-emerald-400 text-[11px]">
                {t("doctors.availableToday")}
              </Badge>
            )}
            {doctor.videoEnabled && (
              <Badge className="bg-teal-600/10 text-teal-700 dark:text-teal-400 text-[11px] gap-1">
                <Video className="h-3 w-3" />
                {t("doctors.videoReady")}
              </Badge>
            )}
          </div>
        </div>
        {doctor.bio && (
          <p className="text-xs text-muted-foreground line-clamp-2">{doctor.bio}</p>
        )}
        <div className="flex items-center justify-between pt-1">
          <div>
            <span className="text-xs text-muted-foreground">{t("doctors.from")}</span>{" "}
            <span className="font-bold text-foreground">
              {formatMAD(doctor.consultationPrice, t("common.currency"))}
            </span>
          </div>
          <Button size="sm" onClick={onBook} className="gap-1">
            {t("doctors.book")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
