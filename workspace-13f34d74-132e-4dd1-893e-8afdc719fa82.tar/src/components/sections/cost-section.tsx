"use client";

import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calculator, Coins, Info, ShieldCheck, Sparkles } from "lucide-react";
import { estimateCost } from "@/lib/api-client";
import type { CostEstimate } from "@/lib/types";
import { formatMAD } from "@/lib/format";
import { Skeleton } from "@/components/ui/skeleton";

const MOROCCAN_CITIES = [
  "Casablanca",
  "Rabat",
  "Fès",
  "Marrakech",
  "Tanger",
  "Agadir",
  "Meknès",
  "Oujda",
];

const EXAMPLES = [
  "Cardiology consultation",
  "MRI scan (brain)",
  "Dental cleaning",
  "Cesarean delivery",
  "Appendectomy",
];

export function CostSection() {
  const { t, lang } = useI18n();
  const [procedure, setProcedure] = useState("");
  const [city, setCity] = useState("all");
  const [loading, setLoading] = useState(false);
  const [estimate, setEstimate] = useState<CostEstimate | null>(null);

  const estimate_ = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!procedure.trim()) return;
    setLoading(true);
    setEstimate(null);
    try {
      const r = await estimateCost(procedure, city === "all" ? "" : city, lang);
      setEstimate(r);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <Calculator className="h-6 w-6 text-emerald-600" />
          {t("cost.title")}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">{t("cost.subtitle")}</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("cost.estimate")}</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={estimate_} className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="proc">{t("cost.procedure")}</Label>
              <Input
                id="proc"
                value={procedure}
                onChange={(e) => setProcedure(e.target.value)}
                placeholder={t("cost.example")}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="city">{t("cost.city")}</Label>
              <Select value={city} onValueChange={setCity}>
                <SelectTrigger id="city">
                  <SelectValue placeholder={t("hospitals.filter.allCities")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t("hospitals.filter.allCities")}</SelectItem>
                  {MOROCCAN_CITIES.map((c) => (
                    <SelectItem key={c} value={c}>
                      {c}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Examples */}
            <div className="flex flex-wrap gap-1.5 pt-1">
              {EXAMPLES.map((ex) => (
                <button
                  key={ex}
                  type="button"
                  onClick={() => setProcedure(ex)}
                  className="rounded-full border bg-card px-2.5 py-1 text-xs hover:bg-muted transition-colors"
                >
                  {ex}
                </button>
              ))}
            </div>

            <Button type="submit" disabled={loading} className="w-full gap-2">
              {loading ? (
                t("common.loading")
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  {t("cost.estimate")}
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {loading && (
        <Card>
          <CardContent className="p-6 space-y-4">
            <Skeleton className="h-8 w-1/2" />
            <Skeleton className="h-4 w-full" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-20 w-full" />
          </CardContent>
        </Card>
      )}

      {estimate && !loading && (
        <Card className="overflow-hidden">
          <div className="bg-gradient-to-br from-emerald-500 to-teal-600 p-5 text-white">
            <p className="text-sm opacity-90 flex items-center gap-1.5">
              <Coins className="h-4 w-4" />
              {t("cost.range")}
            </p>
            <p className="text-3xl font-bold mt-1">
              {formatMAD(estimate.consultation.min, "")} –{" "}
              {formatMAD(estimate.consultation.max, t("common.currency"))}
            </p>
            <p className="text-xs opacity-80 mt-1">
              {city && city !== "all" ? `${city} · ` : ""}Morocco
            </p>
          </div>
          <CardContent className="p-5 space-y-4">
            {estimate.breakdown.length > 0 && (
              <div>
                <p className="text-sm font-medium mb-2">{t("cost.breakdown")}</p>
                <div className="space-y-1.5">
                  {estimate.breakdown.map((b, i) => (
                    <div
                      key={i}
                      className="flex items-center justify-between rounded-lg bg-muted/40 px-3 py-2 text-sm"
                    >
                      <span className="text-muted-foreground">{b.label}</span>
                      <span className="font-medium">
                        {formatMAD(b.min, "")} – {formatMAD(b.max, t("common.currency"))}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="rounded-lg border border-emerald-200 dark:border-emerald-900/40 bg-emerald-50 dark:bg-emerald-950/20 p-3">
              <p className="text-xs font-medium text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5 mb-1">
                <ShieldCheck className="h-3.5 w-3.5" />
                {t("cost.insurance")}
              </p>
              <p className="text-sm text-emerald-900 dark:text-emerald-200">
                {estimate.insuranceNote}
              </p>
            </div>

            <div className="rounded-lg border border-amber-200 dark:border-amber-900/40 bg-amber-50 dark:bg-amber-950/20 p-3">
              <p className="text-xs font-medium text-amber-800 dark:text-amber-300 flex items-center gap-1.5 mb-1">
                <Info className="h-3.5 w-3.5" />
                {t("cost.recommendation")}
              </p>
              <p className="text-sm text-amber-900 dark:text-amber-200">
                {estimate.recommendation}
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      <Alert>
        <Info className="h-4 w-4" />
        <AlertDescription className="text-xs text-muted-foreground">
          {t("cost.disclaimer")}
        </AlertDescription>
      </Alert>
    </div>
  );
}
