"use client";

import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth-context";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import {
  CalendarDays,
  Video,
  MapPin,
  Clock,
  CreditCard,
  Stethoscope,
  Building2,
  LogIn,
  CheckCircle2,
  X,
  Calendar as CalendarIcon,
} from "lucide-react";
import {
  fetchAppointments,
  fetchDoctors,
  createAppointment,
  updateAppointment,
} from "@/lib/api-client";
import type { Appointment, Doctor, AppointmentStatus, AppointmentType } from "@/lib/types";
import { formatMAD, nextDays, timeSlots } from "@/lib/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const STATUS_STYLES: Record<AppointmentStatus, string> = {
  PENDING: "bg-amber-500/10 text-amber-700 dark:text-amber-400",
  CONFIRMED: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
  COMPLETED: "bg-sky-500/10 text-sky-700 dark:text-sky-400",
  CANCELLED: "bg-red-500/10 text-red-700 dark:text-red-400",
};

export function AppointmentsSection() {
  const { t, lang } = useI18n();
  const { user } = useAuth();
  const setView = useAppStore((s) => s.setView);
  const bookingDoctorId = useAppStore((s) => s.bookingDoctorId);
  const setStoreBooking = useAppStore((s) => s.setBooking);

  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [booking, setBooking] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const a = await fetchAppointments();
      setAppointments(a);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) load();
    else setLoading(false);
  }, [user]);

  // If we arrived with a booking doctor preselected, open booking flow.
  useEffect(() => {
    if (bookingDoctorId && user?.role === "PATIENT") {
      setBooking(true);
    }
  }, [bookingDoctorId, user]);

  if (!user) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <div className="inline-grid h-14 w-14 place-items-center rounded-2xl bg-muted mb-4">
          <LogIn className="h-7 w-7 text-muted-foreground" />
        </div>
        <h2 className="text-xl font-semibold mb-2">{t("appt.loginToBook")}</h2>
        <Button onClick={() => setView("auth")}>{t("nav.login")}</Button>
      </div>
    );
  }

  if (user.role === "HOSPITAL_ADMIN") {
    // redirect hospital admins to dashboard
    setView("dashboard");
    return null;
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <CalendarDays className="h-6 w-6 text-emerald-600" />
            {t("appt.title")}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {loading ? "…" : `${appointments.length}`}
          </p>
        </div>
        <Button onClick={() => setView("doctors")} className="gap-1.5">
          <Stethoscope className="h-4 w-4" />
          {t("appt.new")}
        </Button>
      </div>

      {loading ? (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <Skeleton key={i} className="h-32 rounded-2xl" />
          ))}
        </div>
      ) : appointments.length === 0 ? (
        <Card>
          <CardContent className="p-10 text-center text-muted-foreground">
            <CalendarDays className="h-10 w-10 mx-auto mb-3 opacity-40" />
            {t("appt.empty")}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {appointments.map((a) => (
            <AppointmentCard
              key={a.id}
              appointment={a}
              onChanged={load}
              onJoinVideo={() => {
                useAppStore.getState().setActiveVideo(a.roomId!, a.id);
                setView("video");
              }}
            />
          ))}
        </div>
      )}

      {booking && bookingDoctorId && (
        <BookingDialog
          doctorId={bookingDoctorId}
          onClose={() => {
            setBooking(false);
            setStoreBooking(null, null);
          }}
          onBooked={() => {
            setBooking(false);
            setStoreBooking(null, null);
            load();
            toast.success(t("appt.book.success"));
          }}
        />
      )}
    </div>
  );
}

function AppointmentCard({
  appointment,
  onChanged,
  onJoinVideo,
}: {
  appointment: Appointment;
  onChanged: () => void;
  onJoinVideo: () => void;
}) {
  const { t, lang } = useI18n();
  const [paying, setPaying] = useState(false);

  const dt = new Date(appointment.datetime);
  const dateStr = dt.toLocaleDateString(lang === "ar" ? "ar-MA" : lang === "fr" ? "fr-FR" : "en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
  const timeStr = dt.toLocaleTimeString(lang === "ar" ? "ar-MA" : lang === "fr" ? "fr-FR" : "en-GB", {
    hour: "2-digit",
    minute: "2-digit",
  });

  const doctor = appointment.doctor;
  const hospital = appointment.hospital;
  const docName =
    lang === "ar" && doctor?.nameAr ? doctor.nameAr : doctor?.name ?? "—";

  const payNow = async () => {
    setPaying(true);
    try {
      // Simulated payment flow.
      await new Promise((r) => setTimeout(r, 1200));
      await updateAppointment(appointment.id, {
        paymentStatus: "PAID",
        paymentMethod: "APP",
      });
      toast.success(t("appt.payment.done"));
      onChanged();
    } catch {
      toast.error(t("common.error"));
    } finally {
      setPaying(false);
    }
  };

  const cancel = async () => {
    try {
      await updateAppointment(appointment.id, { status: "CANCELLED" });
      onChanged();
    } catch {
      toast.error(t("common.error"));
    }
  };

  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-semibold">
            {docName.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <h3 className="font-semibold truncate">{docName}</h3>
                <p className="text-sm text-muted-foreground truncate">
                  {lang === "ar" && doctor?.specialtyAr
                    ? doctor.specialtyAr
                    : doctor?.specialty}
                </p>
              </div>
              <Badge className={cn("shrink-0", STATUS_STYLES[appointment.status])}>
                {t(`appt.status.${appointment.status}`)}
              </Badge>
            </div>

            <div className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <CalendarIcon className="h-3.5 w-3.5" />
                <span className="truncate">{dateStr}</span>
              </div>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Clock className="h-3.5 w-3.5" />
                {timeStr}
              </div>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                {appointment.type === "VIDEO" ? (
                  <Video className="h-3.5 w-3.5" />
                ) : (
                  <Building2 className="h-3.5 w-3.5" />
                )}
                {t(`appt.type.${appointment.type}`)}
              </div>
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <CreditCard className="h-3.5 w-3.5" />
                <Badge
                  variant="outline"
                  className={cn(
                    "text-[10px]",
                    appointment.paymentStatus === "PAID"
                      ? "text-emerald-700 dark:text-emerald-400 border-emerald-500/30"
                      : "text-amber-700 dark:text-amber-400 border-amber-500/30",
                  )}
                >
                  {t(`appt.payment.${appointment.paymentStatus}`)}
                </Badge>
              </div>
            </div>

            {hospital && (
              <p className="mt-2 text-xs text-muted-foreground flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {hospital.name}
              </p>
            )}

            {doctor && (
              <p className="mt-1 text-xs text-muted-foreground">
                {t("doctors.from")}{" "}
                <span className="font-semibold text-foreground">
                  {formatMAD(doctor.consultationPrice, t("common.currency"))}
                </span>
              </p>
            )}

            <div className="mt-3 flex flex-wrap gap-2">
              {appointment.type === "VIDEO" &&
                appointment.status !== "CANCELLED" &&
                appointment.status !== "COMPLETED" && (
                  <Button size="sm" onClick={onJoinVideo} className="gap-1.5">
                    <Video className="h-3.5 w-3.5" />
                    {t("appt.joinVideo")}
                  </Button>
                )}
              {appointment.paymentStatus === "UNPAID" &&
                appointment.status !== "CANCELLED" && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={payNow}
                    disabled={paying}
                    className="gap-1.5"
                  >
                    <CreditCard className="h-3.5 w-3.5" />
                    {paying ? t("appt.payment.processing") : t("appt.payNow")}
                  </Button>
                )}
              {(appointment.status === "PENDING" ||
                appointment.status === "CONFIRMED") && (
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={cancel}
                  className="gap-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/20"
                >
                  <X className="h-3.5 w-3.5" />
                  {t("appt.cancel")}
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function BookingDialog({
  doctorId,
  onClose,
  onBooked,
}: {
  doctorId: string;
  onClose: () => void;
  onBooked: () => void;
}) {
  const { t, lang } = useI18n();
  const [doctor, setDoctor] = useState<Doctor | null>(null);
  const [date, setDate] = useState<string>("");
  const [time, setTime] = useState<string>("");
  const [type, setType] = useState<AppointmentType>("IN_PERSON");
  const [notes, setNotes] = useState("");
  const [paymentMethod, setPaymentMethod] = useState<"APP" | "HOSPITAL" | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchDoctors({}).then(() => {});
    // Fetch the specific doctor
    fetch(`/api/doctors/${doctorId}`)
      .then((r) => r.json())
      .then((j) => setDoctor(j.doctor));
  }, [doctorId]);

  const days = nextDays(10);

  const submit = async () => {
    if (!date || !time) {
      toast.error(t("appt.book.selectDate"));
      return;
    }
    setLoading(true);
    try {
      const dt = new Date(`${date}T${time}:00`);
      await createAppointment({
        doctorId,
        datetime: dt.toISOString(),
        type,
        notes: notes || undefined,
        paymentMethod,
      });
      onBooked();
    } catch (e: any) {
      toast.error(e?.message || t("common.error"));
    } finally {
      setLoading(false);
    }
  };

  const docName =
    lang === "ar" && doctor?.nameAr ? doctor.nameAr : doctor?.name ?? "…";

  return (
    <div className="fixed inset-0 z-50 grid place-items-end sm:place-items-center bg-black/40 p-0 sm:p-4">
      <Card className="w-full sm:max-w-lg max-h-[92vh] overflow-y-auto rounded-t-2xl sm:rounded-2xl">
        <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-lg">{t("appt.book.title")}</CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {doctor && (
            <div className="flex items-center gap-3 rounded-lg bg-muted/40 p-3">
              <div className="grid h-10 w-10 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm font-semibold">
                {docName.charAt(0)}
              </div>
              <div className="min-w-0">
                <p className="font-medium truncate">{docName}</p>
                <p className="text-xs text-muted-foreground truncate">
                  {lang === "ar" && doctor.specialtyAr ? doctor.specialtyAr : doctor.specialty}
                  {doctor.hospitalName ? ` · ${doctor.hospitalName}` : ""}
                </p>
              </div>
              <span className="ms-auto text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                {formatMAD(doctor.consultationPrice, t("common.currency"))}
              </span>
            </div>
          )}

          {/* Date */}
          <div className="space-y-1.5">
            <Label>{t("appt.book.selectDate")}</Label>
            <div className="flex gap-2 overflow-x-auto sehati-scroll pb-1">
              {days.map((d) => {
                const iso = d.toISOString().slice(0, 10);
                const active = date === iso;
                return (
                  <button
                    key={iso}
                    onClick={() => setDate(iso)}
                    className={cn(
                      "shrink-0 flex flex-col items-center justify-center rounded-lg border w-16 h-16 transition-colors",
                      active ? "border-primary bg-primary text-primary-foreground" : "hover:bg-muted",
                    )}
                  >
                    <span className="text-[10px] uppercase opacity-80">
                      {d.toLocaleDateString(lang === "ar" ? "ar-MA" : lang === "fr" ? "fr-FR" : "en-GB", { weekday: "short" })}
                    </span>
                    <span className="text-lg font-bold">{d.getDate()}</span>
                    <span className="text-[10px] opacity-80">
                      {d.toLocaleDateString(lang === "ar" ? "ar-MA" : lang === "fr" ? "fr-FR" : "en-GB", { month: "short" })}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Time */}
          <div className="space-y-1.5">
            <Label>{t("appt.book.selectTime")}</Label>
            <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
              {timeSlots().map((ts) => {
                const active = time === ts;
                return (
                  <button
                    key={ts}
                    onClick={() => setTime(ts)}
                    className={cn(
                      "rounded-lg border py-2 text-sm font-medium transition-colors",
                      active ? "border-primary bg-primary text-primary-foreground" : "hover:bg-muted",
                    )}
                  >
                    {ts}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Type */}
          <div className="space-y-1.5">
            <Label>{t("appt.book.type")}</Label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setType("IN_PERSON")}
                className={cn(
                  "flex items-center justify-center gap-2 rounded-lg border py-3 text-sm font-medium transition-colors",
                  type === "IN_PERSON" ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted",
                )}
              >
                <Building2 className="h-4 w-4" />
                {t("appt.type.IN_PERSON")}
              </button>
              <button
                onClick={() => setType("VIDEO")}
                disabled={!doctor?.videoEnabled}
                className={cn(
                  "flex items-center justify-center gap-2 rounded-lg border py-3 text-sm font-medium transition-colors disabled:opacity-40 disabled:cursor-not-allowed",
                  type === "VIDEO" ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted",
                )}
              >
                <Video className="h-4 w-4" />
                {t("appt.type.VIDEO")}
              </button>
            </div>
          </div>

          {/* Payment */}
          <div className="space-y-1.5">
            <Label>{t("appt.book.payment")}</Label>
            <p className="text-xs text-muted-foreground">{t("appt.book.paymentHint")}</p>
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={() => setPaymentMethod(null)}
                className={cn(
                  "rounded-lg border py-2.5 text-xs font-medium transition-colors",
                  paymentMethod === null ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted",
                )}
              >
                {t("appt.payment.later")}
              </button>
              <button
                onClick={() => setPaymentMethod("APP")}
                className={cn(
                  "rounded-lg border py-2.5 text-xs font-medium transition-colors",
                  paymentMethod === "APP" ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted",
                )}
              >
                {t("appt.payment.app")}
              </button>
              <button
                onClick={() => setPaymentMethod("HOSPITAL")}
                className={cn(
                  "rounded-lg border py-2.5 text-xs font-medium transition-colors",
                  paymentMethod === "HOSPITAL" ? "border-primary bg-primary/5 text-primary" : "hover:bg-muted",
                )}
              >
                {t("appt.payment.hospital")}
              </button>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <Label htmlFor="notes">{t("appt.book.notes")}</Label>
            <textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={t("appt.book.notesPlaceholder")}
              className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm resize-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            />
          </div>

          <div className="flex gap-2 pt-2">
            <Button variant="outline" onClick={onClose} className="flex-1">
              {t("common.cancel")}
            </Button>
            <Button onClick={submit} disabled={loading} className="flex-1 gap-1.5">
              {loading ? (
                t("common.loading")
              ) : (
                <>
                  <CheckCircle2 className="h-4 w-4" />
                  {t("appt.book.confirm")}
                </>
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}


