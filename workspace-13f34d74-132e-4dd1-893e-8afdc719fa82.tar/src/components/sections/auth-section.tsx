"use client";

import { useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Heart, Stethoscope, Building2 } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import type { Lang, Role } from "@/lib/types";

export function AuthSection() {
  const { t, lang: currentLang } = useI18n();
  const { login, signup } = useAuth();
  const setView = useAppStore((s) => s.setView);

  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [loading, setLoading] = useState(false);

  // shared
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  // signup-only
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [role, setRole] = useState<Role>("PATIENT");
  const [hospitalName, setHospitalName] = useState("");
  const [hospitalCity, setHospitalCity] = useState("");
  const [hospitalAddress, setHospitalAddress] = useState("");
  const [hospitalType, setHospitalType] = useState<
    "PUBLIC" | "PRIVATE" | "CLINIC"
  >("PRIVATE");
  const [hospitalPhone, setHospitalPhone] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signin") {
        const u = await login(email, password);
        toast.success(t("auth.created"));
        setView(u.role === "HOSPITAL_ADMIN" ? "dashboard" : "home");
      } else {
        const u = await signup({
          email,
          password,
          name,
          phone: phone || undefined,
          role,
          language: currentLang as Lang,
          hospitalName: role === "HOSPITAL_ADMIN" ? hospitalName : undefined,
          hospitalCity: role === "HOSPITAL_ADMIN" ? hospitalCity : undefined,
          hospitalAddress: role === "HOSPITAL_ADMIN" ? hospitalAddress : undefined,
          hospitalType: role === "HOSPITAL_ADMIN" ? hospitalType : undefined,
          hospitalPhone: role === "HOSPITAL_ADMIN" ? hospitalPhone : undefined,
        });
        toast.success(t("auth.created"));
        setView(u.role === "HOSPITAL_ADMIN" ? "dashboard" : "home");
      }
    } catch (e: any) {
      const msg = e?.message;
      if (msg === "INVALID") toast.error(t("auth.invalid"));
      else if (msg === "EXISTS") toast.error(t("auth.exists"));
      else toast.error(t("common.error"));
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="text-center mb-6">
        <div className="inline-grid h-14 w-14 place-items-center rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-lg mb-3">
          <Heart className="h-7 w-7 fill-white" />
        </div>
        <h1 className="text-2xl font-bold">{t("auth.welcome")}</h1>
        <p className="text-sm text-muted-foreground mt-1">{t("auth.subtitle")}</p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="grid grid-cols-2 gap-1 p-1 bg-muted rounded-lg">
            <button
              onClick={() => setMode("signin")}
              className={cn(
                "py-2 text-sm font-medium rounded-md transition-colors",
                mode === "signin" ? "bg-background shadow-sm" : "text-muted-foreground",
              )}
            >
              {t("auth.signIn")}
            </button>
            <button
              onClick={() => setMode("signup")}
              className={cn(
                "py-2 text-sm font-medium rounded-md transition-colors",
                mode === "signup" ? "bg-background shadow-sm" : "text-muted-foreground",
              )}
            >
              {t("auth.signUp")}
            </button>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-3">
            {mode === "signup" && (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="name">{t("auth.name")}</Label>
                  <Input
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                    minLength={2}
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("auth.role")}</Label>
                  <RadioGroup
                    value={role}
                    onValueChange={(v) => setRole(v as Role)}
                    className="grid grid-cols-2 gap-2"
                  >
                    <label
                      className={cn(
                        "flex items-center gap-2 rounded-lg border p-3 cursor-pointer transition-colors",
                        role === "PATIENT" && "border-primary bg-primary/5",
                      )}
                    >
                      <RadioGroupItem value="PATIENT" />
                      <Stethoscope className="h-4 w-4 text-emerald-600" />
                      <span className="text-sm font-medium">{t("auth.role.PATIENT")}</span>
                    </label>
                    <label
                      className={cn(
                        "flex items-center gap-2 rounded-lg border p-3 cursor-pointer transition-colors",
                        role === "HOSPITAL_ADMIN" && "border-primary bg-primary/5",
                      )}
                    >
                      <RadioGroupItem value="HOSPITAL_ADMIN" />
                      <Building2 className="h-4 w-4 text-emerald-600" />
                      <span className="text-sm font-medium">
                        {t("auth.role.HOSPITAL_ADMIN")}
                      </span>
                    </label>
                  </RadioGroup>
                </div>

                {role === "HOSPITAL_ADMIN" && (
                  <div className="space-y-3 rounded-lg border p-3 bg-muted/30">
                    <div className="space-y-1.5">
                      <Label htmlFor="hname">{t("auth.hospitalName")}</Label>
                      <Input
                        id="hname"
                        value={hospitalName}
                        onChange={(e) => setHospitalName(e.target.value)}
                        required
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1.5">
                        <Label htmlFor="hcity">{t("auth.hospitalCity")}</Label>
                        <Input
                          id="hcity"
                          value={hospitalCity}
                          onChange={(e) => setHospitalCity(e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="htype">{t("auth.hospitalType")}</Label>
                        <Select
                          value={hospitalType}
                          onValueChange={(v) => setHospitalType(v as any)}
                        >
                          <SelectTrigger id="htype">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="PUBLIC">{t("hospitals.type.PUBLIC")}</SelectItem>
                            <SelectItem value="PRIVATE">{t("hospitals.type.PRIVATE")}</SelectItem>
                            <SelectItem value="CLINIC">{t("hospitals.type.CLINIC")}</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="haddr">{t("auth.hospitalAddress")}</Label>
                      <Input
                        id="haddr"
                        value={hospitalAddress}
                        onChange={(e) => setHospitalAddress(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="hphone">{t("auth.hospitalPhone")}</Label>
                      <Input
                        id="hphone"
                        value={hospitalPhone}
                        onChange={(e) => setHospitalPhone(e.target.value)}
                      />
                    </div>
                  </div>
                )}

                <div className="space-y-1.5">
                  <Label htmlFor="phone">{t("auth.phone")}</Label>
                  <Input
                    id="phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+212 6XX XXX XXX"
                  />
                </div>
              </>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="email">{t("auth.email")}</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                autoComplete="email"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="password">{t("auth.password")}</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                minLength={6}
                autoComplete={mode === "signin" ? "current-password" : "new-password"}
              />
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? t("common.loading") : mode === "signin" ? t("auth.continue") : t("auth.continue")}
            </Button>
          </form>

          <div className="mt-4 text-center text-sm text-muted-foreground">
            {mode === "signin" ? (
              <button
                onClick={() => setMode("signup")}
                className="text-primary hover:underline font-medium"
              >
                {t("auth.noAccount")}
              </button>
            ) : (
              <button
                onClick={() => setMode("signin")}
                className="text-primary hover:underline font-medium"
              >
                {t("auth.haveAccount")}
              </button>
            )}
          </div>

          {mode === "signin" && (
            <div className="mt-4 rounded-lg border border-dashed p-3 text-xs text-muted-foreground space-y-1">
              <p className="font-medium text-foreground">Demo accounts:</p>
              <p>Patient — patient@sehati.ma / patient123</p>
              <p>Hospital admin — admin@chuibnrochd.ma / hospital123</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
