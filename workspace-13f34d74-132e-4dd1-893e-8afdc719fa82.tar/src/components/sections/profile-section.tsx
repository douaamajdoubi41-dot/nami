"use client";

import { useI18n } from "@/lib/i18n";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  User,
  Mail,
  Phone,
  Building2,
  LogOut,
  Heart,
  Stethoscope,
  CalendarDays,
} from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { LanguageSwitcher } from "@/components/ui-custom/language-switcher";
import { useTheme } from "next-themes";

export function ProfileSection() {
  const { t } = useI18n();
  const { user, logout } = useAuth();
  const setView = useAppStore((s) => s.setView);
  const { theme, setTheme } = useTheme();
  const toggleTheme = () => setTheme(theme === "dark" ? "light" : "dark");

  if (!user) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <p className="text-muted-foreground">{t("appt.loginToBook")}</p>
        <Button onClick={() => setView("auth")} className="mt-4">
          {t("nav.login")}
        </Button>
      </div>
    );
  }

  const onLogout = async () => {
    await logout();
    setView("home");
  };

  const shortcuts =
    user.role === "HOSPITAL_ADMIN"
      ? [
          {
            icon: <Building2 className="h-5 w-5" />,
            label: t("nav.dashboard"),
            view: "dashboard" as const,
          },
        ]
      : [
          {
            icon: <CalendarDays className="h-5 w-5" />,
            label: t("nav.appointments"),
            view: "appointments" as const,
          },
          {
            icon: <Stethoscope className="h-5 w-5" />,
            label: t("nav.doctors"),
            view: "doctors" as const,
          },
          {
            icon: <Heart className="h-5 w-5" />,
            label: t("nav.assistant"),
            view: "assistant" as const,
          },
        ];

  return (
    <div className="max-w-md mx-auto space-y-4">
      <div className="text-center mb-2">
        <div className="inline-grid h-20 w-20 place-items-center rounded-3xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-2xl font-bold shadow-lg mb-3">
          {user.name.charAt(0).toUpperCase()}
        </div>
        <h1 className="text-xl font-bold">{user.name}</h1>
        <Badge
          variant="secondary"
          className="mt-1"
        >
          {user.role === "HOSPITAL_ADMIN"
            ? t("auth.role.HOSPITAL_ADMIN")
            : t("auth.role.PATIENT")}
        </Badge>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("nav.profile")}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Row icon={<Mail className="h-4 w-4" />} value={user.email} />
          {user.phone && (
            <Row icon={<Phone className="h-4 w-4" />} value={user.phone} />
          )}
          {user.role === "HOSPITAL_ADMIN" && (
            <Row
              icon={<Building2 className="h-4 w-4" />}
              value={t("auth.role.HOSPITAL_ADMIN")}
            />
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("home.quickActions")}</CardTitle>
        </CardHeader>
        <CardContent className="grid grid-cols-3 gap-2">
          {shortcuts.map((s) => (
            <button
              key={s.view}
              onClick={() => setView(s.view)}
              className="flex flex-col items-center gap-2 rounded-xl border p-3 hover:bg-muted transition-colors"
            >
              <span className="grid h-10 w-10 place-items-center rounded-full bg-emerald-600/10 text-emerald-600">
                {s.icon}
              </span>
              <span className="text-xs font-medium text-center leading-tight">
                {s.label}
              </span>
            </button>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">{t("nav.language")}</CardTitle>
        </CardHeader>
        <CardContent className="flex items-center justify-between">
          <LanguageSwitcher />
          <Button variant="outline" size="sm" onClick={toggleTheme}>
            {theme === "light" ? "🌙 Dark" : "☀️ Light"}
          </Button>
        </CardContent>
      </Card>

      <Button
        variant="outline"
        onClick={onLogout}
        className="w-full gap-2 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/20"
      >
        <LogOut className="h-4 w-4" />
        {t("nav.logout")}
      </Button>
    </div>
  );
}

function Row({ icon, value }: { icon: React.ReactNode; value: string }) {
  return (
    <div className="flex items-center gap-2.5 text-sm">
      <span className="text-muted-foreground">{icon}</span>
      <span className="truncate">{value}</span>
    </div>
  );
}
