"use client";

import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth-context";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  LayoutDashboard,
  Stethoscope,
  CalendarDays,
  Plus,
  Video,
  Clock,
  CheckCircle2,
  XCircle,
  Loader2,
  Users,
} from "lucide-react";
import {
  fetchDashboardDoctors,
  fetchDashboardAppointments,
  addDoctor,
} from "@/lib/api-client";
import { updateAppointment } from "@/lib/api-client";
import type { Doctor, Appointment, AppointmentStatus } from "@/lib/types";
import { formatMAD } from "@/lib/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

const SPECIALTIES = [
  "General",
  "Cardiology",
  "Pediatrics",
  "Dermatology",
  "Orthopedics",
  "Gynecology",
  "Ophthalmology",
  "Neurology",
  "Psychiatry",
  "Dentistry",
  "Radiology",
  "ENT",
];

export function DashboardSection() {
  const { t, lang } = useI18n();
  const { user } = useAuth();
  const setView = useAppStore((s) => s.setView);
  const setActiveVideo = useAppStore((s) => s.setActiveVideo);

  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [appts, setAppts] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);

  // add-doctor form
  const [name, setName] = useState("");
  const [nameAr, setNameAr] = useState("");
  const [specialty, setSpecialty] = useState(SPECIALTIES[0]);
  const [price, setPrice] = useState("200");
  const [videoEnabled, setVideoEnabled] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const [d, a] = await Promise.all([
        fetchDashboardDoctors(),
        fetchDashboardAppointments(),
      ]);
      setDoctors(d);
      setAppts(a);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user?.role === "HOSPITAL_ADMIN") load();
    else setLoading(false);
  }, [user]);

  if (!user) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <p className="text-muted-foreground">{t("appt.loginToBook")}</p>
        <Button onClick={() => setView("auth")} className="mt-4">
          {t("nav.login")}
        </Button>
      </div>
    );
  }

  if (user.role !== "HOSPITAL_ADMIN") {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <LayoutDashboard className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
        <p className="font-medium">{t("dash.notHospital")}</p>
        <Button onClick={() => setView("home")} className="mt-4">
          {t("nav.home")}
        </Button>
      </div>
    );
  }

  const stats = {
    doctors: doctors.length,
    appointments: appts.length,
    pending: appts.filter((a) => a.status === "PENDING").length,
    confirmed: appts.filter((a) => a.status === "CONFIRMED").length,
  };

  const onAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !specialty) return;
    setSaving(true);
    try {
      await addDoctor({
        name,
        nameAr: nameAr || undefined,
        specialty,
        consultationPrice: Number(price) || 0,
        videoEnabled,
        availableToday: true,
      });
      setName("");
      setNameAr("");
      setPrice("200");
      toast.success(t("dash.doctor.save"));
      load();
    } catch (e: any) {
      toast.error(e?.message || t("common.error"));
    } finally {
      setSaving(false);
    }
  };

  const changeStatus = async (id: string, status: AppointmentStatus) => {
    try {
      await updateAppointment(id, { status });
      load();
    } catch {
      toast.error(t("common.error"));
    }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <LayoutDashboard className="h-6 w-6 text-emerald-600" />
          {t("dash.title")}
        </h1>
        <p className="text-sm text-muted-foreground mt-1">{t("dash.subtitle")}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard
          icon={<Users className="h-5 w-5" />}
          label={t("dash.stats.doctors")}
          value={stats.doctors}
          color="from-emerald-500 to-teal-600"
        />
        <StatCard
          icon={<CalendarDays className="h-5 w-5" />}
          label={t("dash.stats.appointments")}
          value={stats.appointments}
          color="from-teal-500 to-cyan-600"
        />
        <StatCard
          icon={<Clock className="h-5 w-5" />}
          label={t("dash.stats.pending")}
          value={stats.pending}
          color="from-amber-500 to-orange-600"
        />
        <StatCard
          icon={<CheckCircle2 className="h-5 w-5" />}
          label={t("dash.stats.confirmed")}
          value={stats.confirmed}
          color="from-rose-500 to-pink-600"
        />
      </div>

      <Tabs defaultValue="appointments">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="appointments" className="gap-1.5">
            <CalendarDays className="h-4 w-4" />
            {t("dash.appointments")}
          </TabsTrigger>
          <TabsTrigger value="doctors" className="gap-1.5">
            <Stethoscope className="h-4 w-4" />
            {t("dash.doctors")}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="appointments" className="space-y-3 mt-4">
          {loading ? (
            <div className="space-y-2">
              {[0, 1].map((i) => (
                <Skeleton key={i} className="h-24 rounded-xl" />
              ))}
            </div>
          ) : appts.length === 0 ? (
            <Card>
              <CardContent className="p-10 text-center text-muted-foreground">
                {t("dash.noAppointments")}
              </CardContent>
            </Card>
          ) : (
            appts.map((a) => {
              const dt = new Date(a.datetime);
              return (
                <Card key={a.id}>
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium">
                            {a.user?.name ?? "—"}
                          </span>
                          {a.user?.phone && (
                            <span className="text-xs text-muted-foreground">
                              {a.user.phone}
                            </span>
                          )}
                          <Badge
                            className={cn(
                              "text-[10px]",
                              a.status === "PENDING" && "bg-amber-500/10 text-amber-700 dark:text-amber-400",
                              a.status === "CONFIRMED" && "bg-emerald-500/10 text-emerald-700 dark:text-emerald-400",
                              a.status === "COMPLETED" && "bg-sky-500/10 text-sky-700 dark:text-sky-400",
                              a.status === "CANCELLED" && "bg-red-500/10 text-red-700 dark:text-red-400",
                            )}
                          >
                            {t(`appt.status.${a.status}`)}
                          </Badge>
                          {a.type === "VIDEO" && (
                            <Badge variant="outline" className="text-[10px] gap-1">
                              <Video className="h-3 w-3" />
                              {t("appt.type.VIDEO")}
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1">
                          {a.doctor?.name} ·{" "}
                          {lang === "ar" && a.doctor?.specialtyAr
                            ? a.doctor.specialtyAr
                            : a.doctor?.specialty}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {dt.toLocaleString(lang === "ar" ? "ar-MA" : lang === "fr" ? "fr-FR" : "en-GB")}
                        </p>
                        {a.notes && (
                          <p className="text-xs mt-1 text-muted-foreground italic">
                            “{a.notes}”
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col gap-1.5 shrink-0">
                        {a.status === "PENDING" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => changeStatus(a.id, "CONFIRMED")}
                            className="gap-1 text-xs"
                          >
                            <CheckCircle2 className="h-3 w-3" />
                            {t("dash.confirm")}
                          </Button>
                        )}
                        {a.status === "CONFIRMED" && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => changeStatus(a.id, "COMPLETED")}
                            className="gap-1 text-xs"
                          >
                            <CheckCircle2 className="h-3 w-3" />
                            {t("dash.complete")}
                          </Button>
                        )}
                        {(a.status === "PENDING" || a.status === "CONFIRMED") && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => changeStatus(a.id, "CANCELLED")}
                            className="gap-1 text-xs text-red-600 hover:text-red-700"
                          >
                            <XCircle className="h-3 w-3" />
                            {t("dash.cancel")}
                          </Button>
                        )}
                        {a.type === "VIDEO" &&
                          (a.status === "CONFIRMED" || a.status === "PENDING") &&
                          a.roomId && (
                            <Button
                              size="sm"
                              onClick={() => {
                                setActiveVideo(a.roomId!, a.id);
                                setView("video");
                              }}
                              className="gap-1 text-xs"
                            >
                              <Video className="h-3 w-3" />
                              {t("appt.joinVideo")}
                            </Button>
                          )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })
          )}
        </TabsContent>

        <TabsContent value="doctors" className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-base flex items-center gap-2">
                <Plus className="h-4 w-4 text-emerald-600" />
                {t("dash.addDoctor")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={onAdd} className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="dname">{t("dash.doctor.name")}</Label>
                  <Input
                    id="dname"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="dnamear">{t("dash.doctor.name")} (عربي)</Label>
                  <Input
                    id="dnamear"
                    value={nameAr}
                    onChange={(e) => setNameAr(e.target.value)}
                    dir="rtl"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label>{t("dash.doctor.specialty")}</Label>
                  <Select value={specialty} onValueChange={setSpecialty}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {SPECIALTIES.map((s) => (
                        <SelectItem key={s} value={s}>
                          {lang === "ar" ? t(`specialty.${s}`, {}) !== `specialty.${s}` ? t(`specialty.${s}`) : s : s}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="price">{t("dash.doctor.price")}</Label>
                  <Input
                    id="price"
                    type="number"
                    min="0"
                    value={price}
                    onChange={(e) => setPrice(e.target.value)}
                    required
                  />
                </div>
                <div className="flex items-center gap-2 sm:col-span-2">
                  <Switch
                    id="video"
                    checked={videoEnabled}
                    onCheckedChange={setVideoEnabled}
                  />
                  <Label htmlFor="video" className="cursor-pointer">
                    {t("dash.doctor.video")}
                  </Label>
                </div>
                <Button
                  type="submit"
                  disabled={saving}
                  className="sm:col-span-2 gap-1.5"
                >
                  {saving ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Plus className="h-4 w-4" />
                      {t("dash.doctor.save")}
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {loading ? (
            <div className="space-y-2">
              {[0, 1].map((i) => (
                <Skeleton key={i} className="h-20 rounded-xl" />
              ))}
            </div>
          ) : doctors.length === 0 ? (
            <Card>
              <CardContent className="p-10 text-center text-muted-foreground">
                {t("dash.noDoctors")}
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-2">
              {doctors.map((d) => (
                <Card key={d.id}>
                  <CardContent className="p-3 flex items-center gap-3">
                    <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm font-semibold">
                      {(lang === "ar" && d.nameAr ? d.nameAr : d.name).charAt(0)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium truncate">
                        {lang === "ar" && d.nameAr ? d.nameAr : d.name}
                      </p>
                      <p className="text-xs text-muted-foreground truncate">
                        {lang === "ar" && d.specialtyAr ? d.specialtyAr : d.specialty}
                      </p>
                    </div>
                    {d.videoEnabled && (
                      <Badge variant="outline" className="text-[10px] gap-1">
                        <Video className="h-3 w-3" />
                        {t("doctors.videoReady")}
                      </Badge>
                    )}
                    <span className="text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                      {formatMAD(d.consultationPrice, t("common.currency"))}
                    </span>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: number;
  color: string;
}) {
  return (
    <Card>
      <CardContent className="p-4">
        <div
          className={cn(
            "grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br text-white mb-2",
            color,
          )}
        >
          {icon}
        </div>
        <p className="text-2xl font-bold">{value}</p>
        <p className="text-xs text-muted-foreground">{label}</p>
      </CardContent>
    </Card>
  );
}
