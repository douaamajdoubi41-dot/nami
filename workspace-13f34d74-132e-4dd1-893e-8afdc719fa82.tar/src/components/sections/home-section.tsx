"use client";

import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  MapPin,
  Building2,
  Stethoscope,
  Bot,
  Calculator,
  Siren,
  ArrowLeft,
  ArrowRight,
  Phone,
  Star,
  Navigation,
} from "lucide-react";
import {
  fetchHospitals,
  fetchDoctors,
} from "@/lib/api-client";
import type { Hospital, Doctor } from "@/lib/types";
import { HospitalBadges, DistanceChip } from "@/components/ui-custom/hospital-badges";
import { RatingStars } from "@/components/ui-custom/rating-stars";
import { formatMAD } from "@/lib/format";
import { cn } from "@/lib/utils";

export function HomeSection() {
  const { t, lang, dir } = useI18n();
  const setView = useAppStore((s) => s.setView);
  const setBooking = useAppStore((s) => s.setBooking);
  const search = useAppStore((s) => s.search);
  const setSearch = useAppStore((s) => s.setSearch);
  const userLat = useAppStore((s) => s.userLat);
  const userLng = useAppStore((s) => s.userLng);
  const locationEnabled = useAppStore((s) => s.locationEnabled);
  const setLocation = useAppStore((s) => s.setLocation);
  const clearLocation = useAppStore((s) => s.clearLocation);

  const [nearby, setNearby] = useState<(Hospital & { doctorCount?: number })[]>([]);
  const [topDoctors, setTopDoctors] = useState<Doctor[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const [h, d] = await Promise.all([
        fetchHospitals({
          limit: 6,
          q: search,
          lat: userLat ?? undefined,
          lng: userLng ?? undefined,
        }),
        fetchDoctors({ limit: 6, availableToday: true }),
      ]);
      setNearby(h.hospitals);
      setTopDoctors(d.doctors);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [search, userLat, userLng]);

  const useLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setLocation(pos.coords.latitude, pos.coords.longitude),
      () => clearLocation(),
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  const Arrow = dir === "rtl" ? ArrowLeft : ArrowRight;

  const quickActions = [
    {
      icon: <Building2 className="h-5 w-5" />,
      label: t("home.findHospital"),
      view: "hospitals" as const,
      color: "from-emerald-500 to-teal-600",
    },
    {
      icon: <Stethoscope className="h-5 w-5" />,
      label: t("home.bookDoctor"),
      view: "doctors" as const,
      color: "from-teal-500 to-cyan-600",
    },
    {
      icon: <Bot className="h-5 w-5" />,
      label: t("home.aiHelp"),
      view: "assistant" as const,
      color: "from-amber-500 to-orange-600",
    },
    {
      icon: <Calculator className="h-5 w-5" />,
      label: t("home.estimateCost"),
      view: "cost" as const,
      color: "from-rose-500 to-pink-600",
    },
  ];

  return (
    <div className="space-y-8">
      {/* Hero */}
      <section className="relative overflow-hidden rounded-3xl border bg-gradient-to-br from-emerald-50 via-teal-50/40 to-amber-50/40 dark:from-emerald-950/30 dark:via-teal-950/20 dark:to-amber-950/10 sehati-hero-gradient">
        <div className="relative p-6 md:p-10">
          <Badge className="mb-4 gap-1.5 bg-emerald-600/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-600/15">
            <span className="sehati-pulse h-2 w-2 rounded-full bg-emerald-500 inline-block" />
            {t("app.tagline")} · Morocco 🇲🇦
          </Badge>
          <h1 className="text-3xl md:text-5xl font-bold tracking-tight text-foreground max-w-2xl">
            {t("home.greeting")}
          </h1>
          <p className="mt-3 text-base md:text-lg text-muted-foreground max-w-xl">
            {t("home.subtitle")}
          </p>

          {/* Search */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              setView("hospitals");
            }}
            className="mt-6 relative max-w-xl"
          >
            <Search className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground rtl:right-4 rtl:left-auto" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={t("home.searchPlaceholder")}
              className="h-12 pl-12 pr-4 text-base rounded-xl bg-background/80 backdrop-blur shadow-sm rtl:pl-4 rtl:pr-12"
            />
          </form>

          <div className="mt-4 flex flex-wrap items-center gap-2">
            <Button
              variant={locationEnabled ? "default" : "outline"}
              size="sm"
              onClick={useLocation}
              className="gap-1.5"
            >
              <Navigation className="h-4 w-4" />
              {t("home.useLocation")}
            </Button>
            {!locationEnabled && (
              <span className="text-xs text-muted-foreground">
                {t("home.locationOff")}
              </span>
            )}
          </div>
        </div>
      </section>

      {/* Emergency banner */}
      <button
        onClick={() => setView("hospitals")}
        className="block w-full text-start group"
      >
        <div className="flex items-center gap-4 rounded-2xl border border-red-200 dark:border-red-900/50 bg-gradient-to-r from-red-50 to-rose-50 dark:from-red-950/30 dark:to-rose-950/20 p-4 transition-all group-hover:shadow-md">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-xl bg-red-600 text-white">
            <Siren className="h-6 w-6" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-semibold text-red-700 dark:text-red-400">
              {t("home.emergency")}
            </p>
            <p className="text-sm text-muted-foreground truncate">
              {t("home.emergencyDesc")}
            </p>
          </div>
          <Arrow className="h-5 w-5 text-red-600 shrink-0 transition-transform group-hover:translate-x-1 rtl:group-hover:-translate-x-1" />
        </div>
      </button>

      {/* Quick actions */}
      <section>
        <h2 className="text-lg font-semibold mb-3">{t("home.quickActions")}</h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {quickActions.map((a) => (
            <button
              key={a.view}
              onClick={() => setView(a.view)}
              className="group relative overflow-hidden rounded-2xl border bg-card p-4 text-start transition-all hover:shadow-md hover:-translate-y-0.5"
            >
              <div
                className={cn(
                  "grid h-11 w-11 place-items-center rounded-xl bg-gradient-to-br text-white shadow-sm mb-3",
                  a.color,
                )}
              >
                {a.icon}
              </div>
              <p className="text-sm font-semibold leading-tight">{a.label}</p>
              <Arrow className="absolute top-4 end-4 h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
            </button>
          ))}
        </div>
      </section>

      {/* Nearby hospitals */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <MapPin className="h-5 w-5 text-emerald-600" />
            {t("home.nearbyHospitals")}
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setView("hospitals")}
            className="gap-1"
          >
            {t("home.viewAll")}
            <Arrow className="h-4 w-4" />
          </Button>
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[0, 1, 2].map((i) => (
              <div
                key={i}
                className="h-44 rounded-2xl bg-muted animate-pulse"
              />
            ))}
          </div>
        ) : nearby.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              {t("hospitals.noResults")}
            </CardContent>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {nearby.map((h) => (
              <HospitalCard
                key={h.id}
                hospital={h}
                onBook={() => {
                  setBooking(null, h.id);
                  setView("doctors");
                }}
              />
            ))}
          </div>
        )}
      </section>

      {/* Top doctors */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold flex items-center gap-2">
            <Stethoscope className="h-5 w-5 text-emerald-600" />
            {t("home.topDoctors")}
          </h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setView("doctors")}
            className="gap-1"
          >
            {t("home.viewAll")}
            <Arrow className="h-4 w-4" />
          </Button>
        </div>

        {loading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="h-40 rounded-2xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : topDoctors.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              {t("doctors.noResults")}
            </CardContent>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {topDoctors.map((d) => (
              <DoctorCard
                key={d.id}
                doctor={d}
                onBook={() => {
                  setBooking(d.id, d.hospitalId);
                  setView("appointments");
                }}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function HospitalCard({
  hospital,
  onBook,
}: {
  hospital: Hospital & { doctorCount?: number };
  onBook: () => void;
}) {
  const { t, lang } = useI18n();
  const name =
    lang === "ar" && hospital.nameAr
      ? hospital.nameAr
      : lang === "en" && hospital.nameEn
        ? hospital.nameEn
        : hospital.name;
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="h-24 bg-gradient-to-br from-emerald-500/15 via-teal-500/10 to-amber-500/10 relative">
        <div className="absolute inset-0 grid place-items-center">
          <Building2 className="h-10 w-10 text-emerald-600/40" />
        </div>
      </div>
      <CardContent className="p-4 space-y-3">
        <div>
          <h3 className="font-semibold leading-tight line-clamp-1">{name}</h3>
          <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
            <MapPin className="h-3 w-3" />
            {hospital.city}
          </p>
        </div>
        <HospitalBadges hospital={hospital} />
        <div className="flex items-center justify-between">
          <RatingStars value={hospital.rating} />
          {hospital.distanceKm != null && <DistanceChip km={hospital.distanceKm} />}
        </div>
        <div className="flex gap-2 pt-1">
          <Button
            size="sm"
            variant="outline"
            className="flex-1 gap-1.5"
            onClick={() => (window.location.href = `tel:${hospital.phone}`)}
          >
            <Phone className="h-3.5 w-3.5" />
            {t("hospitals.call")}
          </Button>
          <Button size="sm" className="flex-1" onClick={onBook}>
            {t("hospitals.bookHere")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

function DoctorCard({ doctor, onBook }: { doctor: Doctor; onBook: () => void }) {
  const { t, lang } = useI18n();
  const name = lang === "ar" && doctor.nameAr ? doctor.nameAr : doctor.name;
  const specialty =
    lang === "ar" && doctor.specialtyAr
      ? doctor.specialtyAr
      : t(`specialty.${doctor.specialty}`, {}) !== `specialty.${doctor.specialty}`
        ? t(`specialty.${doctor.specialty}`)
        : doctor.specialty;
  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-start gap-3">
          <div className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-semibold">
            {name.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-semibold leading-tight truncate">{name}</h3>
            <p className="text-sm text-muted-foreground truncate">
              {specialty}
            </p>
            <p className="text-xs text-muted-foreground truncate mt-0.5">
              {doctor.hospitalName ? `${t("doctors.at")} ${doctor.hospitalName}` : ""}
            </p>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <RatingStars value={doctor.rating} />
          {doctor.availableToday ? (
            <Badge className="bg-emerald-600/10 text-emerald-700 dark:text-emerald-400 text-[11px]">
              {t("doctors.availableToday")}
            </Badge>
          ) : (
            <Badge variant="secondary" className="text-[11px]">
              {t("doctors.unavailable")}
            </Badge>
          )}
        </div>
        <div className="flex items-center justify-between pt-1">
          <div>
            <span className="text-xs text-muted-foreground">{t("doctors.from")}</span>{" "}
            <span className="font-semibold text-emerald-700 dark:text-emerald-400">
              {formatMAD(doctor.consultationPrice, t("common.currency"))}
            </span>
          </div>
          <Button size="sm" onClick={onBook} className="gap-1">
            {t("doctors.book")}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
