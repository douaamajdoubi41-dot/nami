"use client";

import { useEffect, useState } from "react";
import { useI18n } from "@/lib/i18n";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Building2,
  MapPin,
  Phone,
  Navigation,
  Filter,
  Search,
  Siren,
  Clock,
  Ambulance,
} from "lucide-react";
import { fetchHospitals, fetchHospital } from "@/lib/api-client";
import type { Hospital, Doctor, HospitalType } from "@/lib/types";
import { HospitalBadges, DistanceChip } from "@/components/ui-custom/hospital-badges";
import { RatingStars } from "@/components/ui-custom/rating-stars";
import { formatMAD } from "@/lib/format";
import { cn } from "@/lib/utils";

export function HospitalsSection() {
  const { t, lang } = useI18n();
  const search = useAppStore((s) => s.search);
  const userLat = useAppStore((s) => s.userLat);
  const userLng = useAppStore((s) => s.userLng);
  const setLocation = useAppStore((s) => s.setLocation);
  const clearLocation = useAppStore((s) => s.clearLocation);
  const setView = useAppStore((s) => s.setView);
  const setBooking = useAppStore((s) => s.setBooking);
  const locationEnabled = useAppStore((s) => s.locationEnabled);

  const [hospitals, setHospitals] = useState<(Hospital & { doctorCount?: number })[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [localSearch, setLocalSearch] = useState("");
  const [city, setCity] = useState<string>("all");
  const [type, setType] = useState<string>("all");
  const [open24h, setOpen24h] = useState(false);
  const [emergency, setEmergency] = useState(false);
  const [ambulance, setAmbulance] = useState(false);
  const [selected, setSelected] = useState<Hospital | null>(null);

  const load = async () => {
    setLoading(true);
    try {
      const q = localSearch || search;
      const r = await fetchHospitals({
        q,
        city: city === "all" ? undefined : city,
        type: type === "all" ? undefined : type,
        open24h,
        emergency,
        ambulance,
        lat: userLat ?? undefined,
        lng: userLng ?? undefined,
      });
      setHospitals(r.hospitals);
      setCities(r.cities);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [search, city, type, open24h, emergency, ambulance, userLat, userLng]);

  const useLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setLocation(pos.coords.latitude, pos.coords.longitude),
      () => clearLocation(),
      { enableHighAccuracy: true, timeout: 8000 },
    );
  };

  const toggle = (fn: (v: boolean) => void, val: boolean) => fn(!val);

  const Filters = (
    <div className="space-y-4">
      <div className="space-y-2">
        <label className="text-sm font-medium">{t("hospitals.filter.city")}</label>
        <Select value={city} onValueChange={setCity}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder={t("hospitals.filter.allCities")} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("hospitals.filter.allCities")}</SelectItem>
            {cities.map((c) => (
              <SelectItem key={c} value={c}>
                {c}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium">{t("hospitals.filter.type")}</label>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-full">
            <SelectValue placeholder={t("hospitals.filter.allTypes")} />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">{t("hospitals.filter.allTypes")}</SelectItem>
            <SelectItem value="PUBLIC">{t("hospitals.type.PUBLIC")}</SelectItem>
            <SelectItem value="PRIVATE">{t("hospitals.type.PRIVATE")}</SelectItem>
            <SelectItem value="CLINIC">{t("hospitals.type.CLINIC")}</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="space-y-2">
        <FilterToggle
          active={open24h}
          onClick={() => setOpen24h(!open24h)}
          icon={<Clock className="h-4 w-4" />}
          label={t("hospitals.filter.openNow")}
        />
        <FilterToggle
          active={emergency}
          onClick={() => setEmergency(!emergency)}
          icon={<Siren className="h-4 w-4" />}
          label={t("hospitals.filter.emergency")}
        />
        <FilterToggle
          active={ambulance}
          onClick={() => setAmbulance(!ambulance)}
          icon={<Ambulance className="h-4 w-4" />}
          label={t("hospitals.filter.ambulance")}
        />
      </div>
    </div>
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <Building2 className="h-6 w-6 text-emerald-600" />
            {t("hospitals.title")}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {loading ? "…" : `${hospitals.length} ${t("hospitals.results")}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant={locationEnabled ? "default" : "outline"}
            size="sm"
            onClick={useLocation}
            className="gap-1.5"
          >
            <Navigation className="h-4 w-4" />
            <span className="hidden sm:inline">{t("home.useLocation")}</span>
          </Button>
          {/* Mobile filter sheet */}
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1.5 lg:hidden">
                <Filter className="h-4 w-4" />
                {t("hospitals.filter.type")}
              </Button>
            </SheetTrigger>
            <SheetContent side={lang === "ar" ? "left" : "right"} className="w-[300px] overflow-y-auto">
              <SheetHeader>
                <SheetTitle>{t("hospitals.filter.type")}</SheetTitle>
              </SheetHeader>
              <div className="px-4 pb-6">{Filters}</div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Search + filters row */}
      <div className="flex gap-3">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground rtl:right-3 rtl:left-auto" />
          <Input
            value={localSearch}
            onChange={(e) => setLocalSearch(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && load()}
            placeholder={t("home.searchPlaceholder")}
            className="pl-9 rtl:pl-3 rtl:pr-9"
          />
        </div>
        <Button onClick={load}>{t("common.search")}</Button>
      </div>

      <div className="grid lg:grid-cols-[260px_1fr] gap-5">
        {/* Desktop filters */}
        <aside className="hidden lg:block">
          <Card className="sticky top-24">
            <CardContent className="p-4">{Filters}</CardContent>
          </Card>
        </aside>

        {/* Results */}
        <div className="space-y-3">
          {loading ? (
            <div className="grid sm:grid-cols-2 gap-3">
              {[0, 1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-48 rounded-2xl" />
              ))}
            </div>
          ) : hospitals.length === 0 ? (
            <Card>
              <CardContent className="p-10 text-center text-muted-foreground">
                {t("hospitals.noResults")}
              </CardContent>
            </Card>
          ) : (
            <div className="grid sm:grid-cols-2 gap-3">
              {hospitals.map((h) => (
                <HospitalListItem
                  key={h.id}
                  hospital={h}
                  onSelect={() => setSelected(h)}
                  onBook={() => {
                    setBooking(null, h.id);
                    setView("doctors");
                  }}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Detail dialog */}
      {selected && (
        <HospitalDetail
          key={selected.id}
          hospital={selected}
          onClose={() => setSelected(null)}
          onBook={() => {
            setBooking(null, selected.id);
            setView("doctors");
            setSelected(null);
          }}
        />
      )}
    </div>
  );
}

function FilterToggle({
  active,
  onClick,
  icon,
  label,
}: {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex w-full items-center gap-2 rounded-lg border px-3 py-2 text-sm font-medium transition-colors",
        active
          ? "border-primary bg-primary/5 text-primary"
          : "border-border hover:bg-muted",
      )}
    >
      {icon}
      {label}
      {active && <span className="ms-auto text-xs">✓</span>}
    </button>
  );
}

function HospitalListItem({
  hospital,
  onSelect,
  onBook,
}: {
  hospital: Hospital & { doctorCount?: number };
  onSelect: () => void;
  onBook: () => void;
}) {
  const { t, lang } = useI18n();
  const name =
    lang === "ar" && hospital.nameAr
      ? hospital.nameAr
      : lang === "en" && hospital.nameEn
        ? hospital.nameEn
        : hospital.name;
  return (
    <Card className="overflow-hidden hover:shadow-md transition-shadow">
      <div className="flex">
        <button
          onClick={onSelect}
          className="w-24 shrink-0 bg-gradient-to-br from-emerald-500/20 via-teal-500/15 to-amber-500/15 grid place-items-center"
        >
          <Building2 className="h-8 w-8 text-emerald-600/50" />
        </button>
        <CardContent className="flex-1 p-4 space-y-2.5">
          <button onClick={onSelect} className="block text-start w-full">
            <h3 className="font-semibold leading-tight">{name}</h3>
            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
              <MapPin className="h-3 w-3" />
              {hospital.city} · {hospital.address}
            </p>
          </button>
          <HospitalBadges hospital={hospital} />
          <div className="flex items-center justify-between">
            <RatingStars value={hospital.rating} />
            {hospital.distanceKm != null && <DistanceChip km={hospital.distanceKm} />}
          </div>
          {hospital.services.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {hospital.services.slice(0, 4).map((s, i) => (
                <Badge key={i} variant="outline" className="text-[10px] font-normal">
                  {s}
                </Badge>
              ))}
            </div>
          )}
          <div className="flex gap-2 pt-1">
            <Button
              size="sm"
              variant="outline"
              className="flex-1 gap-1.5"
              onClick={() => (window.location.href = `tel:${hospital.phone}`)}
            >
              <Phone className="h-3.5 w-3.5" />
              {t("hospitals.call")}
            </Button>
            <Button size="sm" className="flex-1" onClick={onBook}>
              {t("hospitals.bookHere")}
            </Button>
          </div>
        </CardContent>
      </div>
    </Card>
  );
}

function HospitalDetail({
  hospital,
  onClose,
  onBook,
}: {
  hospital: Hospital;
  onClose: () => void;
  onBook: () => void;
}) {
  const { t, lang } = useI18n();
  const [doctors, setDoctors] = useState<Doctor[]>([]);
  const [loadingDocs, setLoadingDocs] = useState(true);
  const setBooking = useAppStore((s) => s.setBooking);
  const setView = useAppStore((s) => s.setView);

  useEffect(() => {
    let active = true;
    fetchHospital(hospital.id)
      .then((r) => {
        if (active) setDoctors(r.doctors);
      })
      .finally(() => {
        if (active) setLoadingDocs(false);
      });
    return () => {
      active = false;
    };
  }, [hospital.id]);

  const name =
    lang === "ar" && hospital.nameAr
      ? hospital.nameAr
      : lang === "en" && hospital.nameEn
        ? hospital.nameEn
        : hospital.name;

  return (
    <Sheet open onOpenChange={(o) => !o && onClose()}>
      <SheetContent
        side={lang === "ar" ? "left" : "right"}
        className="w-full sm:max-w-lg overflow-y-auto"
      >
        <SheetHeader>
          <SheetTitle>{name}</SheetTitle>
        </SheetHeader>
        <div className="px-4 pb-8 space-y-4">
          <div className="h-32 rounded-xl bg-gradient-to-br from-emerald-500/20 via-teal-500/15 to-amber-500/15 grid place-items-center">
            <Building2 className="h-12 w-12 text-emerald-600/40" />
          </div>
          <HospitalBadges hospital={hospital} />
          <p className="text-sm text-muted-foreground flex items-center gap-1.5">
            <MapPin className="h-4 w-4" />
            {hospital.address}, {hospital.city}
          </p>
          <p className="text-sm text-muted-foreground flex items-center gap-1.5">
            <Phone className="h-4 w-4" />
            {hospital.phone}
          </p>
          <RatingStars value={hospital.rating} size={16} />
          {hospital.description && <p className="text-sm">{hospital.description}</p>}
          {hospital.services.length > 0 && (
            <div>
              <p className="text-sm font-medium mb-1.5">{t("hospitals.services")}</p>
              <div className="flex flex-wrap gap-1.5">
                {hospital.services.map((s, i) => (
                  <Badge key={i} variant="secondary">
                    {s}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          <div>
            <p className="text-sm font-medium mb-2">{t("hospitals.doctors")}</p>
            {loadingDocs ? (
              <div className="space-y-2">
                {[0, 1].map((i) => (
                  <Skeleton key={i} className="h-16 rounded-lg" />
                ))}
              </div>
            ) : doctors.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                {t("doctors.noResults")}
              </p>
            ) : (
              <div className="space-y-2">
                {doctors.map((d) => {
                  const dname =
                    lang === "ar" && d.nameAr ? d.nameAr : d.name;
                  return (
                    <button
                      key={d.id}
                      onClick={() => {
                        setBooking(d.id, hospital.id);
                        setView("appointments");
                        onClose();
                      }}
                      className="flex w-full items-center gap-3 rounded-lg border p-3 text-start hover:bg-muted/50 transition-colors"
                    >
                      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 text-white text-sm font-semibold">
                        {dname.charAt(0)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium truncate">{dname}</p>
                        <p className="text-xs text-muted-foreground truncate">
                          {lang === "ar" && d.specialtyAr ? d.specialtyAr : d.specialty}
                        </p>
                      </div>
                      <span className="text-sm font-semibold text-emerald-700 dark:text-emerald-400">
                        {formatMAD(d.consultationPrice, t("common.currency"))}
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          <Button className="w-full" onClick={onBook}>
            {t("hospitals.bookHere")}
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
}
