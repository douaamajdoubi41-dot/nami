"use client";

import { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import { useI18n } from "@/lib/i18n";
import { useAuth } from "@/lib/auth-context";
import { useAppStore } from "@/store/app-store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import {
  Video,
  Mic,
  MicOff,
  VideoOff,
  PhoneOff,
  Users,
  ArrowLeft,
  Loader2,
} from "lucide-react";
import { cn } from "@/lib/utils";

type CallState = "connecting" | "waiting" | "active" | "ended";

export function VideoSection() {
  const { t } = useI18n();
  const setView = useAppStore((s) => s.setView);
  const activeRoomId = useAppStore((s) => s.activeRoomId);
  const clearActiveVideo = useAppStore((s) => s.clearActiveVideo);

  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const socketRef = useRef<Socket | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const peerSocketIdRef = useRef<string | null>(null);

  const [state, setState] = useState<CallState>("connecting");
  const [micOn, setMicOn] = useState(true);
  const [camOn, setCamOn] = useState(true);
  const [peerMicOn, setPeerMicOn] = useState(true);
  const [peerCamOn, setPeerCamOn] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Determine role: if user is HOSPITAL_ADMIN assume doctor, otherwise patient.
  const { user } = useAuth();
  const role: "patient" | "doctor" =
    user?.role === "HOSPITAL_ADMIN" ? "doctor" : "patient";
  const myName = user?.name ?? "User";

  useEffect(() => {
    if (!activeRoomId) return;

    let cancelled = false;
    const iceServers: RTCIceServer[] = [
      { urls: "stun:stun.l.google.com:19302" },
      { urls: "stun:stun1.l.google.com:19302" },
    ];

    const start = async () => {
      try {
        // 1. Get user media.
        const stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: true,
        });
        if (cancelled) {
          stream.getTracks().forEach((tr) => tr.stop());
          return;
        }
        localStreamRef.current = stream;
        if (localVideoRef.current) {
          localVideoRef.current.srcObject = stream;
        }

        // 2. Set up RTCPeerConnection.
        const pc = new RTCPeerConnection({ iceServers });
        pcRef.current = pc;
        stream.getTracks().forEach((tr) => pc.addTrack(tr, stream));

        pc.ontrack = (ev) => {
          if (remoteVideoRef.current) {
            remoteVideoRef.current.srcObject = ev.streams[0];
          }
        };
        pc.onicecandidate = (ev) => {
          if (ev.candidate && socketRef.current && peerSocketIdRef.current) {
            // Forward to the peer via signaling.
            socketRef.current.emit("ice-candidate", {
              to: peerSocketIdRef.current,
              candidate: ev.candidate,
            });
          }
        };

        // 3. Connect socket.io to the video signaling service on port 3004.
        const sock = io("/?XTransformPort=3004", {
          transports: ["websocket", "polling"],
          forceNew: true,
          reconnection: true,
          reconnectionAttempts: 5,
        });
        socketRef.current = sock;

        sock.on("connect", () => {
          setState("waiting");
          sock.emit("join-room", { roomId: activeRoomId, role, name: myName });
        });

        // If a peer is already in the room, we are the initiator.
        sock.on("peer-ready", async (data: { socketId: string }) => {
          if (cancelled) return;
          peerSocketIdRef.current = data.socketId;
          try {
            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);
            sock.emit("offer", { to: data.socketId, sdp: offer });
          } catch (e) {
            console.error("offer error", e);
          }
        });

        sock.on("peer-joined", (data: { socketId: string; role: string; name: string }) => {
          if (cancelled) return;
          peerSocketIdRef.current = data.socketId;
          // A peer joined — we may receive their offer soon (they are the initiator).
          setState("active");
        });

        sock.on("offer", async (data: { from: string; sdp: RTCSessionDescriptionInit }) => {
          if (cancelled) return;
          peerSocketIdRef.current = data.from;
          try {
            await pc.setRemoteDescription(data.sdp);
            const answer = await pc.createAnswer();
            await pc.setLocalDescription(answer);
            sock.emit("answer", { to: data.from, sdp: answer });
            setState("active");
          } catch (e) {
            console.error("answer error", e);
          }
        });

        sock.on("answer", async (data: { from: string; sdp: RTCSessionDescriptionInit }) => {
          if (cancelled) return;
          peerSocketIdRef.current = data.from;
          try {
            await pc.setRemoteDescription(data.sdp);
            setState("active");
          } catch (e) {
            console.error("setRemoteDescription error", e);
          }
        });

        // ice-candidate forwarded from the peer.
        sock.on("ice-candidate", async (data: { from: string; candidate: RTCIceCandidateInit }) => {
          if (cancelled) return;
          try {
            if (data.candidate) {
              await pc.addIceCandidate(data.candidate);
            }
          } catch (e) {
            console.error("ice error", e);
          }
        });

        sock.on("toggle-media", (data: { socketId: string; video: boolean; audio: boolean }) => {
          setPeerMicOn(data.audio);
          setPeerCamOn(data.video);
        });

        sock.on("end-call", () => {
          setState("ended");
        });

        sock.on("peer-left", () => {
          setState("ended");
        });

        sock.on("disconnect", () => {
          // keep waiting for reconnect
        });
      } catch (e: any) {
        console.error("video start error", e);
        setError(e?.message || "PERMISSION");
      }
    };

    start();

    return () => {
      cancelled = true;
      try {
        socketRef.current?.emit("end-call", {});
      } catch {}
      socketRef.current?.disconnect();
      pcRef.current?.close();
      localStreamRef.current?.getTracks().forEach((tr) => tr.stop());
    };
  }, [activeRoomId]);

  const toggleMic = () => {
    const next = !micOn;
    setMicOn(next);
    localStreamRef.current?.getAudioTracks().forEach((tr) => (tr.enabled = next));
    socketRef.current?.emit("toggle-media", { video: camOn, audio: next });
  };
  const toggleCam = () => {
    const next = !camOn;
    setCamOn(next);
    localStreamRef.current?.getVideoTracks().forEach((tr) => (tr.enabled = next));
    socketRef.current?.emit("toggle-media", { video: next, audio: micOn });
  };

  const endCall = () => {
    socketRef.current?.emit("end-call", {});
    socketRef.current?.disconnect();
    pcRef.current?.close();
    localStreamRef.current?.getTracks().forEach((tr) => tr.stop());
    setState("ended");
  };

  const leave = () => {
    clearActiveVideo();
    setView("appointments");
  };

  if (!activeRoomId) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <p className="text-muted-foreground">{t("video.permission")}</p>
        <Button onClick={leave} className="mt-4">
          {t("video.back")}
        </Button>
      </div>
    );
  }

  if (error) {
    return (
      <div className="max-w-md mx-auto text-center py-12">
        <VideoOff className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
        <p className="font-medium">{t("video.permission")}</p>
        <Button onClick={leave} className="mt-4">
          {t("video.back")}
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-4">
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="sm" onClick={leave} className="gap-1.5">
          <ArrowLeft className="h-4 w-4 rtl:rotate-180" />
          {t("video.back")}
        </Button>
        <div className="flex items-center gap-2 text-sm">
          {state === "connecting" && (
            <span className="flex items-center gap-1.5 text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              {t("video.connecting")}
            </span>
          )}
          {state === "waiting" && (
            <span className="flex items-center gap-1.5 text-amber-600">
              <span className="sehati-pulse h-2 w-2 rounded-full bg-amber-500 inline-block" />
              {t("video.waiting")}
            </span>
          )}
          {state === "active" && (
            <span className="flex items-center gap-1.5 text-emerald-600">
              <span className="sehati-pulse h-2 w-2 rounded-full bg-emerald-500 inline-block" />
              {t("video.inCall")}
            </span>
          )}
          {state === "ended" && (
            <span className="text-muted-foreground">{t("video.ended")}</span>
          )}
        </div>
      </div>

      <Card className="overflow-hidden">
        <CardContent className="p-0">
          <div className="relative aspect-video bg-slate-900 rounded-2xl overflow-hidden">
            {/* Remote (full) */}
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="absolute inset-0 h-full w-full object-cover"
              style={{ transform: "none" }}
            />
            {!peerCamOn && state === "active" && (
              <div className="absolute inset-0 grid place-items-center bg-slate-900">
                <div className="grid h-20 w-20 place-items-center rounded-full bg-slate-700 text-white">
                  <Users className="h-10 w-10" />
                </div>
                <p className="absolute bottom-1/3 text-sm text-white/70">
                  {t("video.peerCamOff")}
                </p>
              </div>
            )}
            {state !== "active" && (
              <div className="absolute inset-0 grid place-items-center bg-slate-900 text-white/80">
                <div className="text-center">
                  <div className="grid h-20 w-20 place-items-center rounded-full bg-white/10 mx-auto mb-3">
                    {state === "ended" ? (
                      <PhoneOff className="h-10 w-10" />
                    ) : (
                      <Loader2 className="h-10 w-10 animate-spin" />
                    )}
                  </div>
                  <p className="text-sm">
                    {state === "ended"
                      ? t("video.ended")
                      : state === "waiting"
                        ? t("video.waiting")
                        : t("video.connecting")}
                  </p>
                </div>
              </div>
            )}

            {/* Local (picture-in-picture) */}
            <div className="absolute bottom-3 end-3 h-1/4 w-1/4 min-w-[120px] max-w-[200px] rounded-xl overflow-hidden border-2 border-white/20 shadow-lg bg-slate-800">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="h-full w-full object-cover"
                style={{ transform: "scaleX(-1)" }}
              />
              {!camOn && (
                <div className="absolute inset-0 grid place-items-center bg-slate-800">
                  <VideoOff className="h-6 w-6 text-white/60" />
                </div>
              )}
            </div>

            {/* Peer mic off indicator */}
            {state === "active" && !peerMicOn && (
              <div className="absolute top-3 start-3 rounded-full bg-black/50 px-2.5 py-1 text-xs text-white flex items-center gap-1.5">
                <MicOff className="h-3 w-3" />
                {t("video.peerMicOff")}
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="flex items-center justify-center gap-3 p-4">
            <button
              onClick={toggleMic}
              className={cn(
                "grid h-12 w-12 place-items-center rounded-full transition-colors",
                micOn
                  ? "bg-slate-200 dark:bg-slate-700 text-foreground hover:bg-slate-300 dark:hover:bg-slate-600"
                  : "bg-red-600 text-white hover:bg-red-700",
              )}
              aria-label={t("video.mic")}
            >
              {micOn ? <Mic className="h-5 w-5" /> : <MicOff className="h-5 w-5" />}
            </button>
            <button
              onClick={toggleCam}
              className={cn(
                "grid h-12 w-12 place-items-center rounded-full transition-colors",
                camOn
                  ? "bg-slate-200 dark:bg-slate-700 text-foreground hover:bg-slate-300 dark:hover:bg-slate-600"
                  : "bg-red-600 text-white hover:bg-red-700",
              )}
              aria-label={t("video.cam")}
            >
              {camOn ? <Video className="h-5 w-5" /> : <VideoOff className="h-5 w-5" />}
            </button>
            <button
              onClick={endCall}
              className="grid h-12 w-12 place-items-center rounded-full bg-red-600 text-white hover:bg-red-700 transition-colors"
              aria-label={t("video.end")}
            >
              <PhoneOff className="h-5 w-5" />
            </button>
          </div>
        </CardContent>
      </Card>

      <p className="text-center text-xs text-muted-foreground">
        {t("video.title")} · {role}
      </p>
    </div>
  );
}
