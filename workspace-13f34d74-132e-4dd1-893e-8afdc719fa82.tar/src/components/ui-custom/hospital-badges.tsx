"use client";

import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { Clock, Siren, Ambulance, MapPin } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import type { Hospital } from "@/lib/types";

export function HospitalBadges({
  hospital,
  className,
}: {
  hospital: Pick<Hospital, "open24h" | "emergency" | "ambulance" | "type">;
  className?: string;
}) {
  const { t } = useI18n();
  return (
    <div className={cn("flex flex-wrap items-center gap-1.5", className)}>
      <Badge variant="secondary" className="gap-1 text-[11px] font-medium">
        {t(`hospitals.type.${hospital.type}`)}
      </Badge>
      {hospital.open24h && (
        <Badge className="gap-1 bg-emerald-600/10 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-600/15 text-[11px]">
          <Clock className="h-3 w-3" />
          {t("hospitals.open24h")}
        </Badge>
      )}
      {hospital.emergency && (
        <Badge className="gap-1 bg-red-600/10 text-red-700 dark:text-red-400 hover:bg-red-600/15 text-[11px]">
          <Siren className="h-3 w-3" />
          {t("hospitals.emergency")}
        </Badge>
      )}
      {hospital.ambulance && (
        <Badge className="gap-1 bg-amber-600/10 text-amber-700 dark:text-amber-400 hover:bg-amber-600/15 text-[11px]">
          <Ambulance className="h-3 w-3" />
          {t("hospitals.ambulance")}
        </Badge>
      )}
    </div>
  );
}

export function DistanceChip({ km }: { km: number }) {
  const { t } = useI18n();
  if (km == null) return null;
  return (
    <span className="inline-flex items-center gap-1 text-xs text-muted-foreground">
      <MapPin className="h-3 w-3" />
      {km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} ${t("common.km")}`}
    </span>
  );
}
