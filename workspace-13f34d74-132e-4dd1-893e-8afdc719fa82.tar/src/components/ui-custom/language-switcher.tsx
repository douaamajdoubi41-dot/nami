"use client";

import { useI18n } from "@/lib/i18n";
import { LANGS } from "@/lib/i18n";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Globe } from "lucide-react";

export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { lang, setLang } = useI18n();
  const current = LANGS.find((l) => l.code === lang) ?? LANGS[1];

  return (
    <Select value={lang} onValueChange={(v) => setLang(v as any)}>
      <SelectTrigger
        className={
          compact
            ? "h-9 w-[44px] px-2 gap-1"
            : "h-9 w-[130px] gap-2"
        }
        aria-label="Language"
      >
        <Globe className="h-4 w-4 opacity-70" />
        {!compact && (
          <SelectValue placeholder="Lang">
            <span className="flex items-center gap-1.5">
              <span>{current.flag}</span>
              <span>{current.label}</span>
            </span>
          </SelectValue>
        )}
        {compact && <span>{current.flag}</span>}
      </SelectTrigger>
      <SelectContent align="end">
        {LANGS.map((l) => (
          <SelectItem key={l.code} value={l.code}>
            <span className="flex items-center gap-2">
              <span>{l.flag}</span>
              <span>{l.label}</span>
            </span>
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
