"use client";

import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function RatingStars({
  value,
  size = 14,
  className,
}: {
  value: number;
  size?: number;
  className?: string;
}) {
  const rounded = Math.round(value * 2) / 2;
  return (
    <div className={cn("flex items-center gap-0.5", className)}>
      {[1, 2, 3, 4, 5].map((i) => {
        const filled = i <= Math.floor(rounded);
        const half = !filled && i - 0.5 === rounded;
        return (
          <Star
            key={i}
            style={{ width: size, height: size }}
            className={
              filled || half
                ? "fill-amber-400 text-amber-400"
                : "fill-muted text-muted-foreground/40"
            }
          />
        );
      })}
      {value > 0 && (
        <span className="ml-1 text-xs font-medium text-muted-foreground">
          {value.toFixed(1)}
        </span>
      )}
    </div>
  );
}
