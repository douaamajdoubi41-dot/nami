import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";
import { Providers } from "@/components/providers";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "صحتي | Sehati — Smart Healthcare Assistant (Morocco)",
  description:
    "Find nearby hospitals, book doctors, video consultations and AI health guidance across Morocco. صحتي — مساعدك الصحي الذكي في المغرب.",
  keywords: [
    "Sehati",
    "صحتي",
    "Morocco healthcare",
    "hôpitaux Maroc",
    "rendez-vous médecin",
    "téléconsultation",
  ],
  authors: [{ name: "Sehati" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "صحتي | Sehati",
    description: "Smart healthcare assistant for Morocco",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          {children}
          <Toaster />
          <SonnerToaster position="top-center" richColors />
        </Providers>
      </body>
    </html>
  );
}
