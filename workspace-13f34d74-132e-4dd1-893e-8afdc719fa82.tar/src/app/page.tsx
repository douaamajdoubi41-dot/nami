"use client";

import { AppShell } from "@/components/app-shell";
import { useAppStore } from "@/store/app-store";
import { HomeSection } from "@/components/sections/home-section";
import { HospitalsSection } from "@/components/sections/hospitals-section";
import { DoctorsSection } from "@/components/sections/doctors-section";
import { AppointmentsSection } from "@/components/sections/appointments-section";
import { AssistantSection } from "@/components/sections/assistant-section";
import { CostSection } from "@/components/sections/cost-section";
import { VideoSection } from "@/components/sections/video-section";
import { DashboardSection } from "@/components/sections/dashboard-section";
import { AuthSection } from "@/components/sections/auth-section";
import { ProfileSection } from "@/components/sections/profile-section";

export default function Home() {
  const view = useAppStore((s) => s.view);

  return (
    <AppShell>
      {view === "home" && <HomeSection />}
      {view === "hospitals" && <HospitalsSection />}
      {view === "doctors" && <DoctorsSection />}
      {view === "appointments" && <AppointmentsSection />}
      {view === "assistant" && <AssistantSection />}
      {view === "cost" && <CostSection />}
      {view === "video" && <VideoSection />}
      {view === "dashboard" && <DashboardSection />}
      {view === "auth" && <AuthSection />}
      {view === "profile" && <ProfileSection />}
    </AppShell>
  );
}
