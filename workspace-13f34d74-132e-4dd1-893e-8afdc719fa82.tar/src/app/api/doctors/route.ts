import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toDoctor } from "@/lib/format";

// GET /api/doctors
// Query params:
//   specialty, hospitalId, availableToday=1, video=1,
//   q (search by name/specialty), city, limit
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const specialty = searchParams.get("specialty");
  const hospitalId = searchParams.get("hospitalId");
  const availableToday = searchParams.get("availableToday") === "1";
  const video = searchParams.get("video") === "1";
  const q = searchParams.get("q")?.trim();
  const city = searchParams.get("city");
  const limit = searchParams.get("limit")
    ? Number(searchParams.get("limit"))
    : 50;

  const where: any = {};
  if (specialty) where.specialty = specialty;
  if (hospitalId) where.hospitalId = hospitalId;
  if (availableToday) where.availableToday = true;
  if (video) where.videoEnabled = true;
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { nameAr: { contains: q } },
      { specialty: { contains: q } },
      { specialtyAr: { contains: q } },
    ];
  }
  if (city) where.hospital = { city };

  const rows = await db.doctor.findMany({
    where,
    include: { hospital: true },
    take: limit,
    orderBy: { rating: "desc" },
  });

  const doctors = rows.map(toDoctor);

  // Distinct specialties list for filters.
  const specialtyRows = await db.doctor.findMany({
    select: { specialty: true },
    distinct: ["specialty"],
    orderBy: { specialty: "asc" },
  });

  return NextResponse.json({
    doctors,
    specialties: specialtyRows.map((s) => s.specialty),
  });
}
