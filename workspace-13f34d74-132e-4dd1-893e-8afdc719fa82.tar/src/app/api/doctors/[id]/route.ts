import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toDoctor } from "@/lib/format";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const d = await db.doctor.findUnique({
    where: { id },
    include: { hospital: true },
  });
  if (!d) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
  return NextResponse.json({ doctor: toDoctor(d) });
}
