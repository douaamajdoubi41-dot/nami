import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { toAppointment } from "@/lib/format";
import { z } from "zod";
import { randomUUID } from "crypto";

// GET /api/appointments — list the current user's appointments.
export async function GET() {
  const user = await getSession();
  if (!user) return NextResponse.json({ appointments: [] });

  // Hospital admins see appointments for their hospital.
  if (user.role === "HOSPITAL_ADMIN" && user.hospitalId) {
    const rows = await db.appointment.findMany({
      where: { hospitalId: user.hospitalId },
      include: { doctor: { include: { hospital: true } }, hospital: true, user: true },
      orderBy: { datetime: "desc" },
    });
    return NextResponse.json({ appointments: rows.map(toAppointment) });
  }

  const rows = await db.appointment.findMany({
    where: { userId: user.id },
    include: { doctor: { include: { hospital: true } }, hospital: true },
    orderBy: { datetime: "desc" },
  });
  return NextResponse.json({ appointments: rows.map(toAppointment) });
}

const createSchema = z.object({
  doctorId: z.string().min(1),
  datetime: z.string().min(1), // ISO string
  type: z.enum(["IN_PERSON", "VIDEO"]).default("IN_PERSON"),
  notes: z.string().optional(),
  paymentMethod: z.enum(["APP", "HOSPITAL"]).nullable().default(null),
});

// POST /api/appointments — create a new appointment.
export async function POST(req: NextRequest) {
  const user = await getSession();
  if (!user) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }
  if (user.role !== "PATIENT") {
    return NextResponse.json({ error: "PATIENT_ONLY" }, { status: 403 });
  }

  const body = await req.json();
  const parsed = createSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "INVALID_INPUT", details: parsed.error.flatten() },
      { status: 400 },
    );
  }
  const d = parsed.data;

  const doctor = await db.doctor.findUnique({
    where: { id: d.doctorId },
    include: { hospital: true },
  });
  if (!doctor) {
    return NextResponse.json({ error: "DOCTOR_NOT_FOUND" }, { status: 404 });
  }
  if (d.type === "VIDEO" && !doctor.videoEnabled) {
    return NextResponse.json({ error: "VIDEO_NOT_ENABLED" }, { status: 400 });
  }

  const dt = new Date(d.datetime);
  if (isNaN(dt.getTime()) || dt.getTime() < Date.now() - 60_000) {
    return NextResponse.json({ error: "INVALID_DATETIME" }, { status: 400 });
  }

  const appt = await db.appointment.create({
    data: {
      userId: user.id,
      doctorId: doctor.id,
      hospitalId: doctor.hospitalId,
      datetime: dt,
      type: d.type,
      status: "PENDING",
      paymentStatus: d.paymentMethod === "APP" ? "PAID" : "UNPAID",
      paymentMethod: d.paymentMethod,
      notes: d.notes ?? null,
      roomId: d.type === "VIDEO" ? `sehati-${randomUUID()}` : null,
    },
    include: { doctor: { include: { hospital: true } }, hospital: true },
  });

  return NextResponse.json({ appointment: toAppointment(appt) });
}
