import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { toAppointment } from "@/lib/format";
import { z } from "zod";

// PATCH /api/appointments/[id]
// Body: { status?, paymentStatus?, paymentMethod? }
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const user = await getSession();
  if (!user) {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }
  const { id } = await params;

  const appt = await db.appointment.findUnique({
    where: { id },
    include: { doctor: { include: { hospital: true } }, hospital: true },
  });
  if (!appt) {
    return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
  }

  // Authorization: patient owns it OR hospital admin owns the hospital.
  const isOwner = appt.userId === user.id;
  const isHospitalAdmin =
    user.role === "HOSPITAL_ADMIN" && user.hospitalId === appt.hospitalId;
  if (!isOwner && !isHospitalAdmin) {
    return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  }

  const body = await req.json();
  const schema = z.object({
    status: z
      .enum(["PENDING", "CONFIRMED", "COMPLETED", "CANCELLED"])
      .optional(),
    paymentStatus: z.enum(["UNPAID", "PAID"]).optional(),
    paymentMethod: z.enum(["APP", "HOSPITAL"]).optional().nullable(),
  });
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "INVALID_INPUT", details: parsed.error.flatten() },
      { status: 400 },
    );
  }

  // Patients can only cancel their own or pay. Hospital admins can change status.
  const data: any = {};
  if (parsed.data.status) {
    if (!isHospitalAdmin && parsed.data.status !== "CANCELLED") {
      return NextResponse.json({ error: "FORBIDDEN_STATUS" }, { status: 403 });
    }
    data.status = parsed.data.status;
  }
  if (parsed.data.paymentStatus) data.paymentStatus = parsed.data.paymentStatus;
  if (parsed.data.paymentMethod !== undefined)
    data.paymentMethod = parsed.data.paymentMethod;

  const updated = await db.appointment.update({
    where: { id },
    data,
    include: { doctor: { include: { hospital: true } }, hospital: true },
  });

  return NextResponse.json({ appointment: toAppointment(updated) });
}
