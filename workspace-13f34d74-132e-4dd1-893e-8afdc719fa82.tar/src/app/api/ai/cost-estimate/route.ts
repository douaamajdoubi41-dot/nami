import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import type { Lang, CostEstimate } from "@/lib/types";

const schema = z.object({
  procedure: z.string().min(2).max(200),
  city: z.string().optional(),
  lang: z.enum(["ar", "fr", "en"]).default("fr"),
});

const PROMPTS: Record<Lang, string> = {
  fr: `Tu es un estimateur de coûts de santé pour le Maroc.
À partir d'un acte médical décrit par l'utilisateur, estime le prix typique au Maroc en dirhams (MAD).
Réponds UNIQUEMENT en JSON valide avec ce schéma exact:
{
  "consultation": { "min": number, "max": number, "currency": "MAD" },
  "breakdown": [ { "label": string, "min": number, "max": number } ],
  "insuranceNote": string,
  "recommendation": string
}
Règles:
- min et max sont des nombres entiers réalistes (ex: 200, 400).
- Le breakdown doit contenir 2 à 5 lignes (consultation, examens, médicaments éventuels...).
- L'insuranceNote mentionne la prise en charge CNSS/AMO si pertinent.
- La recommendation est une phrase courte conseillant où aller.
- Pas de texte hors JSON.`,
  ar: `نت مقدّر تمن الخدمات الصحية فالمغرب.
بناءً على وصف الخدمة الطبية، قدّر التمن المعتاد فالمغرب بالدرهم.
جاوب غير بـ JSON صحيح بهاد الشكل:
{
  "consultation": { "min": number, "max": number, "currency": "MAD" },
  "breakdown": [ { "label": string, "min": number, "max": number } ],
  "insuranceNote": string,
  "recommendation": string
}
- min و max أرقام حقيقية.
- breakdown من 2 لـ5 سطور.
- insuranceNote ذكر CNSS/AMO إلا لازم.
- recommendation جملة قصيرة فين تمشي.
- بلا نص خارج JSON.`,
  en: `You are a healthcare cost estimator for Morocco.
Given a medical procedure, estimate the typical price in Morocco in dirhams (MAD).
Respond ONLY with valid JSON matching this exact schema:
{
  "consultation": { "min": number, "max": number, "currency": "MAD" },
  "breakdown": [ { "label": string, "min": number, "max": number } ],
  "insuranceNote": string,
  "recommendation": string
}
Rules:
- min and max are realistic integers.
- breakdown has 2 to 5 lines.
- insuranceNote mentions CNSS/AMO coverage when relevant.
- recommendation is a short sentence.
- No text outside the JSON.`,
};

function fallbackEstimate(procedure: string, lang: Lang): CostEstimate {
  const p = procedure.toLowerCase();
  let min = 150,
    max = 400;
  if (/cardio|قلب|card/.test(p)) {
    min = 250;
    max = 500;
  } else if (/scan|mri|radi|أشعة/.test(p)) {
    min = 500;
    max = 1500;
  } else if (/surger|chirurg|oper|جراح/.test(p)) {
    min = 2000;
    max = 8000;
  } else if (/dent|أسنان/.test(p)) {
    min = 300;
    max = 1200;
  }
  const labels: Record<Lang, [string, string, string]> = {
    fr: ["Consultation", "Examens", "Médicaments"],
    ar: ["الاستشارة", "الفحوصات", "الأدوية"],
    en: ["Consultation", "Tests", "Medication"],
  };
  const [c, e, m] = labels[lang];
  const ins: Record<Lang, string> = {
    fr: "La CNSS/AMO peut couvrir une partie selon votre régime.",
    ar: "CNSS/AMO تقدر تغطي جزء حسب النظام ديالك.",
    en: "CNSS/AMO may cover part depending on your regime.",
  };
  const rec: Record<Lang, string> = {
    fr: "Comparez plusieurs établissements avant de réserver.",
    ar: "قارن بين عدة مؤسسات قبل الحجز.",
    en: "Compare several facilities before booking.",
  };
  return {
    consultation: { min, max, currency: "MAD" },
    breakdown: [
      { label: c, min: Math.round(min * 0.7), max: Math.round(max * 0.7) },
      { label: e, min: Math.round(min * 0.2), max: Math.round(max * 0.2) },
      { label: m, min: Math.round(min * 0.1), max: Math.round(max * 0.1) },
    ],
    insuranceNote: ins[lang],
    recommendation: rec[lang],
  };
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "INVALID_INPUT" },
        { status: 400 },
      );
    }
    const { procedure, city, lang } = parsed.data;

    try {
      const ZAI = (await import("z-ai-web-dev-sdk")).default;
      const zai = await ZAI.create();

      const userPrompt = `Acte médical: "${procedure}"${
        city ? ` à ${city}` : ""
      } (Maroc). Estime le coût en MAD.`;

      const completion = await zai.chat.completions.create({
        messages: [
          { role: "assistant", content: PROMPTS[lang] },
          { role: "user", content: userPrompt },
        ],
        thinking: { type: "disabled" },
      });

      const raw = completion.choices?.[0]?.message?.content ?? "";
      // Extract the JSON object from the response.
      const match = raw.match(/\{[\s\S]*\}/);
      if (match) {
        const estimate = JSON.parse(match[0]) as CostEstimate;
        // Basic validation.
        if (
          estimate.consultation &&
          typeof estimate.consultation.min === "number" &&
          typeof estimate.consultation.max === "number" &&
          Array.isArray(estimate.breakdown)
        ) {
          return NextResponse.json({ estimate });
        }
      }
      // If parse failed, fall back.
      return NextResponse.json({ estimate: fallbackEstimate(procedure, lang) });
    } catch (aiErr) {
      console.error("[ai/cost-estimate] SDK error", aiErr);
      return NextResponse.json({ estimate: fallbackEstimate(procedure, lang) });
    }
  } catch (e: any) {
    console.error("[ai/cost-estimate]", e);
    return NextResponse.json({ error: "SERVER" }, { status: 500 });
  }
}
