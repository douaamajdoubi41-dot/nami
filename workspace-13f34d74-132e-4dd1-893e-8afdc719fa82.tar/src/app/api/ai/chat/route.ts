import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import type { Lang } from "@/lib/types";
import { db } from "@/lib/db";

// AI Health Assistant endpoint — uses z-ai-web-dev-sdk (LLM).
// IMPORTANT: SDK is server-side only.

const schema = z.object({
  message: z.string().min(1).max(1000),
  history: z
    .array(
      z.object({
        role: z.enum(["user", "assistant"]),
        content: z.string(),
      }),
    )
    .max(20)
    .default([]),
  lang: z.enum(["ar", "fr", "en"]).default("fr"),
});

const SYSTEM_PROMPTS: Record<Lang, string> = {
  fr: `Tu es "Sehati", l'assistant santé IA d'une application marocaine.
Tu aides les utilisateurs à:
- trouver un hôpital ou une clinique près d'eux au Maroc
- choisir un médecin ou une spécialité appropriée
- estimer si leur situation relève des urgences (numéro 150 au Maroc)
- comprendre les coûts approximatifs des soins en dirhams (MAD)

RÈGLES IMPÉRATIVES:
1. Tu NE DONNES JAMAIS de diagnostic médical. Tu orientes vers une consultation.
2. En cas d'urgence vitale (douleur thoracique intense, difficulté à respirer, saignement abondant, perte de conscience, AVC suspecté), dis clairement d'appeler le 150 ou d'aller aux urgences les plus proches immédiatement.
3. Réponds en français, de manière concise (max 180 mots), chaleureuse et professionnelle.
4. Si pertinent, propose 2-3 spécialités médicales ou types d'établissements adaptés.
5. Ne mentionne jamais de médicaments spécifiques à prendre sans ordonnance.
6. Sois utile et pratique: donne une recommandation d'action claire.`,
  ar: `نت "صحتي"، المساعد الصحي الذكي ديال تطبيق مغربي.
كنعاون المستخدمين باش:
- يلقاو مستشفى ولا مصحة قريبة منهم فالمغرب
- يختارو طبيب ولا تخصص مناسب
- يقدرو يش حالتهم المستعجلة (رقم 150 فالمغرب)
- يفهمو الأثمنة التقريبية للخدمات الطبية بالدرهم

قواعد مهمة:
1. ما كتعطيش التشخيص الطبي أبداً. كتوجّه للاستشارة.
2. فالحالة المستعجلة (وجع الصدر قوي، صعوبة التنفس، نزيف قوي، فقدان الوعي، شكوك فالسكتة الدماغية)، قول بصراحة يتصلو بالـ150 ولا يمشيو للمستعجلات القريبة دغيا.
3. جاوب بالدارجة، باختصار (180 كلمة على الأكثر)، باحترام ومهنية.
4. ملي يكون مناسب، اقترح 2-3 تخصصات طبية ولا أنواع مؤسسات مناسبة.
5. ما تذكرش أدوية محددة بلا وصفة طبية.
6. كن عملي: عطي توصية واضحة.`,
  en: `You are "Sehati", the AI health assistant for a Moroccan healthcare app.
You help users:
- find a hospital or clinic nearby in Morocco
- choose an appropriate doctor or specialty
- assess whether their situation is an emergency (dial 150 in Morocco)
- understand approximate care costs in dirhams (MAD)

STRICT RULES:
1. NEVER give a medical diagnosis. Guide toward a consultation.
2. For life-threatening emergencies (severe chest pain, breathing difficulty, heavy bleeding, unconsciousness, suspected stroke), clearly tell them to call 150 or go to the nearest emergency room immediately.
3. Reply in English, concisely (max 180 words), warm and professional.
4. When relevant, suggest 2-3 suitable medical specialties or facility types.
5. Never recommend specific medications to take without a prescription.
6. Be practical: give a clear action recommendation.`,
};

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "INVALID_INPUT", details: parsed.error.flatten() },
        { status: 400 },
      );
    }
    const { message, history, lang } = parsed.data;

    // Build a small context of available cities/specialties from the DB to make
    // recommendations grounded in real data.
    const cities = await db.hospital.findMany({
      select: { city: true },
      distinct: ["city"],
    });
    const specialties = await db.doctor.findMany({
      select: { specialty: true },
      distinct: ["specialty"],
    });
    const context = `Available cities in app: ${cities.map((c) => c.city).join(", ")}.
Available specialties in app: ${specialties.map((s) => s.specialty).join(", ")}.`;

    // Lazy import so the SDK is never bundled into client code.
    const ZAI = (await import("z-ai-web-dev-sdk")).default;
    const zai = await ZAI.create();

    const messages: any[] = [
      { role: "assistant", content: SYSTEM_PROMPTS[lang] },
      { role: "assistant", content: `App context: ${context}` },
      ...history.slice(-10).map((m) => ({
        role: m.role === "assistant" ? "assistant" : "user",
        content: m.content,
      })),
      { role: "user", content: message },
    ];

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: "disabled" },
    });

    const reply =
      completion.choices?.[0]?.message?.content?.trim() ||
      (lang === "ar"
        ? "ما قدرتش نجاوب دابا. عاود من بعد."
        : lang === "fr"
          ? "Je n'ai pas pu répondre pour le moment."
          : "I couldn't reply right now.");

    return NextResponse.json({ reply });
  } catch (e: any) {
    console.error("[ai/chat]", e);
    return NextResponse.json(
      { error: "AI_ERROR", message: e?.message ?? "unknown" },
      { status: 500 },
    );
  }
}
