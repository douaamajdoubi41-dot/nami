import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession } from "@/lib/auth";
import { toAppointment } from "@/lib/format";

// GET /api/hospital-dashboard/appointments — appointments for the admin's hospital,
// with optional status filter.
export async function GET(req: NextRequest) {
  const user = await getSession();
  if (!user || user.role !== "HOSPITAL_ADMIN" || !user.hospitalId) {
    return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  }
  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status");

  const rows = await db.appointment.findMany({
    where: {
      hospitalId: user.hospitalId,
      ...(status ? { status } : {}),
    },
    include: {
      doctor: { include: { hospital: true } },
      hospital: true,
      user: true,
    },
    orderBy: { datetime: "desc" },
  });

  return NextResponse.json({ appointments: rows.map(toAppointment) });
}
