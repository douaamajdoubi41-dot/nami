import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSession, requireUser } from "@/lib/auth";
import { toDoctor } from "@/lib/format";
import { z } from "zod";

// GET /api/hospital-dashboard/doctors — list doctors for the admin's hospital.
export async function GET() {
  const user = await getSession();
  if (!user || user.role !== "HOSPITAL_ADMIN" || !user.hospitalId) {
    return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  }
  const rows = await db.doctor.findMany({
    where: { hospitalId: user.hospitalId },
    include: { hospital: true },
    orderBy: { createdAt: "desc" },
  });
  return NextResponse.json({ doctors: rows.map(toDoctor) });
}

const schema = z.object({
  name: z.string().min(2),
  nameAr: z.string().optional().nullable(),
  specialty: z.string().min(2),
  specialtyAr: z.string().optional().nullable(),
  consultationPrice: z.number().min(0),
  videoEnabled: z.boolean().default(true),
  availableToday: z.boolean().default(true),
  bio: z.string().optional().nullable(),
});

// POST /api/hospital-dashboard/doctors — add a doctor to the admin's hospital.
export async function POST(req: NextRequest) {
  let user;
  try {
    user = await requireUser();
  } catch {
    return NextResponse.json({ error: "UNAUTHORIZED" }, { status: 401 });
  }
  if (user.role !== "HOSPITAL_ADMIN" || !user.hospitalId) {
    return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
  }

  const body = await req.json();
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: "INVALID_INPUT", details: parsed.error.flatten() },
      { status: 400 },
    );
  }
  const d = parsed.data;

  const doctor = await db.doctor.create({
    data: {
      name: d.name,
      nameAr: d.nameAr ?? null,
      specialty: d.specialty,
      specialtyAr: d.specialtyAr ?? null,
      hospitalId: user.hospitalId,
      consultationPrice: d.consultationPrice,
      videoEnabled: d.videoEnabled,
      availableToday: d.availableToday,
      bio: d.bio ?? null,
      availability: JSON.stringify([
        { day: "MON", start: "09:00", end: "17:00" },
        { day: "TUE", start: "09:00", end: "17:00" },
        { day: "WED", start: "09:00", end: "17:00" },
        { day: "THU", start: "09:00", end: "17:00" },
        { day: "FRI", start: "09:00", end: "13:00" },
        { day: "SAT", start: "09:00", end: "13:00" },
      ]),
    },
    include: { hospital: true },
  });

  return NextResponse.json({ doctor: toDoctor(doctor) });
}
