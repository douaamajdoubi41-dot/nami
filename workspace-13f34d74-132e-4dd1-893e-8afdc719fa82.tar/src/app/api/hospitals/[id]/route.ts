import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toHospital } from "@/lib/format";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const h = await db.hospital.findUnique({
    where: { id },
    include: {
      doctors: {
        orderBy: { rating: "desc" },
      },
    },
  });
  if (!h) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
  return NextResponse.json({
    hospital: { ...toHospital(h), doctorCount: h.doctors.length },
    doctors: h.doctors.map((d) => ({
      id: d.id,
      name: d.name,
      nameAr: d.nameAr,
      specialty: d.specialty,
      specialtyAr: d.specialtyAr,
      consultationPrice: d.consultationPrice,
      rating: d.rating,
      availableToday: d.availableToday,
      videoEnabled: d.videoEnabled,
      bio: d.bio,
    })),
  });
}
