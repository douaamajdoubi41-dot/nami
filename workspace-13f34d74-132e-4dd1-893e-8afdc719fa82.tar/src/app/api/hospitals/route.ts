import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { toHospital } from "@/lib/format";
import type { HospitalType } from "@/lib/types";

// GET /api/hospitals
// Query params:
//   city, type (PUBLIC|PRIVATE|CLINIC),
//   open24h=1, emergency=1, ambulance=1,
//   q (search), lat, lng (for distance sort), limit
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const city = searchParams.get("city");
  const type = searchParams.get("type") as HospitalType | null;
  const open24h = searchParams.get("open24h") === "1";
  const emergency = searchParams.get("emergency") === "1";
  const ambulance = searchParams.get("ambulance") === "1";
  const q = searchParams.get("q")?.trim();
  const lat = searchParams.get("lat") ? Number(searchParams.get("lat")) : null;
  const lng = searchParams.get("lng") ? Number(searchParams.get("lng")) : null;
  const limit = searchParams.get("limit")
    ? Number(searchParams.get("limit"))
    : 50;

  const where: any = {};
  if (city) where.city = city;
  if (type) where.type = type;
  if (open24h) where.open24h = true;
  if (emergency) where.emergency = true;
  if (ambulance) where.ambulance = true;
  if (q) {
    where.OR = [
      { name: { contains: q } },
      { nameAr: { contains: q } },
      { nameEn: { contains: q } },
      { city: { contains: q } },
      { services: { contains: q } },
    ];
  }

  const rows = await db.hospital.findMany({
    where,
    include: { _count: { select: { doctors: true } } },
    take: limit,
    orderBy: { rating: "desc" },
  });

  let hospitals = rows.map((h) => ({
    ...toHospital(h, lat ?? undefined, lng ?? undefined),
    doctorCount: (h as any)._count?.doctors ?? 0,
  }));

  // Sort by distance if user location is available.
  if (lat != null && lng != null) {
    hospitals = hospitals
      .filter((h) => h.distanceKm != null)
      .sort((a, b) => (a.distanceKm! - b.distanceKm!))
      .concat(hospitals.filter((h) => h.distanceKm == null));
  }

  const cities = await db.hospital.findMany({
    select: { city: true },
    distinct: ["city"],
    orderBy: { city: "asc" },
  });

  return NextResponse.json({
    hospitals,
    cities: cities.map((c) => c.city),
  });
}
