import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, createUserSession, SESSION_COOKIE } from "@/lib/auth";
import type { Lang, Role } from "@/lib/types";
import { z } from "zod";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "INVALID_INPUT" }, { status: 400 });
    }
    const { email, password } = parsed.data;

    const user = await db.user.findUnique({ where: { email } });
    if (!user || user.password !== hashPassword(password)) {
      return NextResponse.json({ error: "INVALID" }, { status: 401 });
    }

    const session = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role as Role,
      language: user.language as Lang,
      phone: user.phone,
      hospitalId: user.hospitalId,
    };
    const token = await createUserSession(session);
    const res = NextResponse.json({ user: session });
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
    return res;
  } catch (e: any) {
    console.error("[login]", e);
    return NextResponse.json({ error: "SERVER" }, { status: 500 });
  }
}
