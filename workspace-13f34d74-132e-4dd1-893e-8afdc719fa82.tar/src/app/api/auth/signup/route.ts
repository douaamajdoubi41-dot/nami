import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { hashPassword, createUserSession, SESSION_COOKIE } from "@/lib/auth";
import type { Lang, Role } from "@/lib/types";
import { z } from "zod";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(2),
  phone: z.string().optional(),
  role: z.enum(["PATIENT", "HOSPITAL_ADMIN"]),
  language: z.enum(["ar", "fr", "en"]).default("fr"),
  // Hospital-admin-only fields:
  hospitalName: z.string().optional(),
  hospitalCity: z.string().optional(),
  hospitalAddress: z.string().optional(),
  hospitalType: z.enum(["PUBLIC", "PRIVATE", "CLINIC"]).optional(),
  hospitalPhone: z.string().optional(),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "INVALID_INPUT", details: parsed.error.flatten() },
        { status: 400 },
      );
    }
    const d = parsed.data;

    const exists = await db.user.findUnique({ where: { email: d.email } });
    if (exists) {
      return NextResponse.json({ error: "EXISTS" }, { status: 409 });
    }

    let hospitalId: string | null = null;
    if (d.role === "HOSPITAL_ADMIN") {
      if (!d.hospitalName || !d.hospitalCity) {
        return NextResponse.json(
          { error: "HOSPITAL_INFO_REQUIRED" },
          { status: 400 },
        );
      }
      const h = await db.hospital.create({
        data: {
          name: d.hospitalName,
          nameAr: null,
          nameEn: d.hospitalName,
          type: d.hospitalType ?? "PRIVATE",
          city: d.hospitalCity,
          address: d.hospitalAddress ?? "",
          // Default to Casablanca center; admin can edit later.
          lat: 33.5731,
          lng: -7.5898,
          phone: d.hospitalPhone ?? "",
          open24h: false,
          emergency: false,
          ambulance: false,
        },
      });
      hospitalId = h.id;
    }

    const user = await db.user.create({
      data: {
        email: d.email,
        password: hashPassword(d.password),
        name: d.name,
        phone: d.phone ?? null,
        role: d.role as Role,
        language: d.language as Lang,
        hospitalId,
      },
    });

    const session = {
      id: user.id,
      email: user.email,
      name: user.name,
      role: user.role as Role,
      language: user.language as Lang,
      phone: user.phone,
      hospitalId: user.hospitalId,
    };
    const token = await createUserSession(session);
    const res = NextResponse.json({ user: session });
    res.cookies.set(SESSION_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 24 * 30,
    });
    return res;
  } catch (e: any) {
    console.error("[signup]", e);
    return NextResponse.json({ error: "SERVER" }, { status: 500 });
  }
}
