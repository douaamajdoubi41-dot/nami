"use client";

import type {
  Hospital,
  Doctor,
  Appointment,
  SessionUser,
  ChatMessage,
  CostEstimate,
  Lang,
} from "@/lib/types";

async function jsonOrThrow<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let msg = res.statusText;
    try {
      const j = await res.json();
      msg = j.error || msg;
    } catch {}
    throw new Error(msg || "REQUEST_FAILED");
  }
  return res.json() as Promise<T>;
}

// --- Auth ---
export async function fetchMe(): Promise<SessionUser | null> {
  try {
    const r = await fetch("/api/auth/me", { cache: "no-store" });
    if (!r.ok) return null;
    const j = await r.json();
    return j.user ?? null;
  } catch {
    return null;
  }
}

export async function doLogin(
  email: string,
  password: string,
): Promise<SessionUser> {
  return jsonOrThrow<{ user: SessionUser }>(
    await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    }),
  ).then((j) => j.user);
}

export async function doSignup(payload: {
  email: string;
  password: string;
  name: string;
  phone?: string;
  role: "PATIENT" | "HOSPITAL_ADMIN";
  language: Lang;
  hospitalName?: string;
  hospitalCity?: string;
  hospitalAddress?: string;
  hospitalType?: "PUBLIC" | "PRIVATE" | "CLINIC";
  hospitalPhone?: string;
}): Promise<SessionUser> {
  return jsonOrThrow<{ user: SessionUser }>(
    await fetch("/api/auth/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  ).then((j) => j.user);
}

export async function doLogout(): Promise<void> {
  await fetch("/api/auth/logout", { method: "POST" });
}

// --- Hospitals ---
export async function fetchHospitals(params: {
  city?: string;
  type?: string;
  open24h?: boolean;
  emergency?: boolean;
  ambulance?: boolean;
  q?: string;
  lat?: number;
  lng?: number;
  limit?: number;
}): Promise<{ hospitals: (Hospital & { doctorCount?: number })[]; cities: string[] }> {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    if (typeof v === "boolean") {
      if (v) sp.set(k, "1");
    } else {
      sp.set(k, String(v));
    }
  }
  return jsonOrThrow(await fetch(`/api/hospitals?${sp.toString()}`));
}

export async function fetchHospital(
  id: string,
): Promise<{ hospital: Hospital; doctors: Doctor[] }> {
  return jsonOrThrow(await fetch(`/api/hospitals/${id}`));
}

// --- Doctors ---
export async function fetchDoctors(params: {
  specialty?: string;
  hospitalId?: string;
  availableToday?: boolean;
  video?: boolean;
  q?: string;
  city?: string;
  limit?: number;
}): Promise<{ doctors: Doctor[]; specialties: string[] }> {
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === null || v === "") continue;
    if (typeof v === "boolean") {
      if (v) sp.set(k, "1");
    } else {
      sp.set(k, String(v));
    }
  }
  return jsonOrThrow(await fetch(`/api/doctors?${sp.toString()}`));
}

// --- Appointments ---
export async function fetchAppointments(): Promise<Appointment[]> {
  const j = await jsonOrThrow<{ appointments: Appointment[] }>(
    await fetch("/api/appointments", { cache: "no-store" }),
  );
  return j.appointments;
}

export async function createAppointment(payload: {
  doctorId: string;
  datetime: string;
  type: "IN_PERSON" | "VIDEO";
  notes?: string;
  paymentMethod?: "APP" | "HOSPITAL" | null;
}): Promise<Appointment> {
  return jsonOrThrow<{ appointment: Appointment }>(
    await fetch("/api/appointments", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  ).then((j) => j.appointment);
}

export async function updateAppointment(
  id: string,
  payload: {
    status?: "PENDING" | "CONFIRMED" | "COMPLETED" | "CANCELLED";
    paymentStatus?: "UNPAID" | "PAID";
    paymentMethod?: "APP" | "HOSPITAL" | null;
  },
): Promise<Appointment> {
  return jsonOrThrow<{ appointment: Appointment }>(
    await fetch(`/api/appointments/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  ).then((j) => j.appointment);
}

// --- Hospital dashboard ---
export async function fetchDashboardDoctors(): Promise<Doctor[]> {
  const j = await jsonOrThrow<{ doctors: Doctor[] }>(
    await fetch("/api/hospital-dashboard/doctors", { cache: "no-store" }),
  );
  return j.doctors;
}

export async function fetchDashboardAppointments(): Promise<Appointment[]> {
  const j = await jsonOrThrow<{ appointments: Appointment[] }>(
    await fetch("/api/hospital-dashboard/appointments", { cache: "no-store" }),
  );
  return j.appointments;
}

export async function addDoctor(payload: {
  name: string;
  nameAr?: string;
  specialty: string;
  specialtyAr?: string;
  consultationPrice: number;
  videoEnabled: boolean;
  availableToday: boolean;
  bio?: string;
}): Promise<Doctor> {
  return jsonOrThrow<{ doctor: Doctor }>(
    await fetch("/api/hospital-dashboard/doctors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    }),
  ).then((j) => j.doctor);
}

// --- AI ---
export async function sendChat(
  message: string,
  history: ChatMessage[],
  lang: Lang,
): Promise<string> {
  const j = await jsonOrThrow<{ reply: string }>(
    await fetch("/api/ai/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        message,
        history: history.map((m) => ({ role: m.role, content: m.content })),
        lang,
      }),
    }),
  );
  return j.reply;
}

export async function estimateCost(
  procedure: string,
  city: string | "",
  lang: Lang,
): Promise<CostEstimate> {
  const j = await jsonOrThrow<{ estimate: CostEstimate }>(
    await fetch("/api/ai/cost-estimate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ procedure, city, lang }),
    }),
  );
  return j.estimate;
}
