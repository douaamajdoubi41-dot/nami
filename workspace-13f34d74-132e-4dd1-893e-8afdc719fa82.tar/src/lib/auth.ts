import { db } from "@/lib/db";
import { cookies } from "next/headers";
import type { SessionUser, Lang } from "@/lib/types";

export const SESSION_COOKIE = "sehati_session";
const SESSIONS = new Map<string, SessionUser>(); // token -> user (in-memory)

function makeToken(): string {
  return (
    Math.random().toString(36).slice(2) +
    Date.now().toString(36) +
    Math.random().toString(36).slice(2)
  );
}

// Hash a password (NOT cryptographically strong — demo only; swap for bcrypt/argon2 in prod).
export function hashPassword(pw: string): string {
  let h = 0x811c9dc5;
  for (let i = 0; i < pw.length; i++) {
    h ^= pw.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return "h" + (h >>> 0).toString(16);
}

export async function createUserSession(user: SessionUser): Promise<string> {
  const token = makeToken();
  SESSIONS.set(token, user);
  return token;
}

export async function getSession(): Promise<SessionUser | null> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  return SESSIONS.get(token) ?? null;
}

export async function requireUser(): Promise<SessionUser> {
  const u = await getSession();
  if (!u) throw new Error("UNAUTHORIZED");
  return u;
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(SESSION_COOKIE)?.value;
  if (token) SESSIONS.delete(token);
}

// Refresh session from DB (e.g. after profile updates).
export async function refreshSession(
  userId: string,
  lang?: Lang,
): Promise<SessionUser | null> {
  const u = await db.user.findUnique({ where: { id: userId } });
  if (!u) return null;
  const session: SessionUser = {
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role as SessionUser["role"],
    language: (lang ?? (u.language as Lang)) || "fr",
    phone: u.phone,
    hospitalId: u.hospitalId,
  };
  // Replace any existing token for this user.
  for (const [tok, su] of SESSIONS.entries()) {
    if (su.id === userId) {
      SESSIONS.set(tok, session);
      return session;
    }
  }
  return session;
}

export { SESSIONS };
