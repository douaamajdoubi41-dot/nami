// صحتي | Sehati — shared types (kept in sync with Prisma schema).
// Using string union aliases for clarity; DB stores them as String (SQLite).

export type Role = "PATIENT" | "HOSPITAL_ADMIN";
export type Lang = "ar" | "fr" | "en";
export type HospitalType = "PUBLIC" | "PRIVATE" | "CLINIC";
export type AppointmentType = "IN_PERSON" | "VIDEO";
export type AppointmentStatus =
  | "PENDING"
  | "CONFIRMED"
  | "COMPLETED"
  | "CANCELLED";
export type PaymentStatus = "UNPAID" | "PAID";
export type PaymentMethod = "APP" | "HOSPITAL";
export type View =
  | "home"
  | "hospitals"
  | "doctors"
  | "appointments"
  | "assistant"
  | "cost"
  | "video"
  | "dashboard"
  | "auth"
  | "profile";

export interface SessionUser {
  id: string;
  email: string;
  name: string;
  role: Role;
  language: Lang;
  phone?: string | null;
  hospitalId?: string | null;
}

export interface Hospital {
  id: string;
  name: string;
  nameAr?: string | null;
  nameEn?: string | null;
  type: HospitalType;
  city: string;
  address: string;
  lat: number;
  lng: number;
  phone: string;
  open24h: boolean;
  emergency: boolean;
  ambulance: boolean;
  rating: number;
  images: string[];
  services: string[];
  description?: string | null;
  distanceKm?: number;
  createdAt: string;
}

export interface Doctor {
  id: string;
  name: string;
  nameAr?: string | null;
  specialty: string;
  specialtyAr?: string | null;
  hospitalId: string;
  hospitalName?: string;
  hospitalCity?: string;
  consultationPrice: number;
  rating: number;
  avatar?: string | null;
  availability: { day: string; start: string; end: string }[];
  availableToday: boolean;
  videoEnabled: boolean;
  bio?: string | null;
  createdAt: string;
}

export interface Appointment {
  id: string;
  userId: string;
  doctorId: string;
  hospitalId: string;
  datetime: string;
  type: AppointmentType;
  status: AppointmentStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: PaymentMethod | null;
  notes?: string | null;
  roomId?: string | null;
  createdAt: string;
  // joined
  doctor?: Doctor;
  hospital?: Hospital;
  user?: { id: string; name: string; phone?: string | null };
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  createdAt: string;
}

export interface CostEstimate {
  consultation: { min: number; max: number; currency: "MAD" };
  breakdown: { label: string; min: number; max: number }[];
  insuranceNote: string;
  recommendation: string;
}
