import type { Hospital, Doctor } from "@/lib/types";

// Haversine distance in km between two coordinates.
export function distanceKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

// Format MAD price, e.g. 350 -> "350 MAD".
export function formatMAD(value: number, currencyLabel = "MAD"): string {
  return `${Math.round(value)} ${currencyLabel}`;
}

export function formatRating(value: number): string {
  return value > 0 ? value.toFixed(1) : "—";
}

// Parse a JSON column safely.
export function parseJsonArray<T>(raw: string | null | undefined): T[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw);
    return Array.isArray(v) ? (v as T[]) : [];
  } catch {
    return [];
  }
}

// Map a Prisma hospital row to the API Hospital shape (with images/services arrays).
export function toHospital(
  h: any,
  userLat?: number | null,
  userLng?: number | null,
): Hospital {
  const distance =
    userLat != null && userLng != null
      ? distanceKm(userLat, userLng, h.lat, h.lng)
      : undefined;
  return {
    id: h.id,
    name: h.name,
    nameAr: h.nameAr,
    nameEn: h.nameEn,
    type: h.type,
    city: h.city,
    address: h.address,
    lat: h.lat,
    lng: h.lng,
    phone: h.phone,
    open24h: h.open24h,
    emergency: h.emergency,
    ambulance: h.ambulance,
    rating: h.rating,
    images: parseJsonArray<string>(h.images),
    services: parseJsonArray<string>(h.services),
    description: h.description,
    distanceKm: distance,
    createdAt: h.createdAt?.toISOString?.() ?? h.createdAt,
  };
}

export function toDoctor(d: any): Doctor {
  return {
    id: d.id,
    name: d.name,
    nameAr: d.nameAr,
    specialty: d.specialty,
    specialtyAr: d.specialtyAr,
    hospitalId: d.hospitalId,
    hospitalName: d.hospital?.name,
    hospitalCity: d.hospital?.city,
    consultationPrice: d.consultationPrice,
    rating: d.rating,
    avatar: d.avatar,
    availability: parseJsonArray(d.availability),
    availableToday: d.availableToday,
    videoEnabled: d.videoEnabled,
    bio: d.bio,
    createdAt: d.createdAt?.toISOString?.() ?? d.createdAt,
  };
}

export function toAppointment(a: any) {
  return {
    id: a.id,
    userId: a.userId,
    doctorId: a.doctorId,
    hospitalId: a.hospitalId,
    datetime: a.datetime?.toISOString?.() ?? a.datetime,
    type: a.type,
    status: a.status,
    paymentStatus: a.paymentStatus,
    paymentMethod: a.paymentMethod,
    notes: a.notes,
    roomId: a.roomId,
    createdAt: a.createdAt?.toISOString?.() ?? a.createdAt,
    doctor: a.doctor ? toDoctor(a.doctor) : undefined,
    hospital: a.hospital ? toHospital(a.hospital) : undefined,
    user: a.user
      ? {
          id: a.user.id,
          name: a.user.name,
          phone: a.user.phone,
        }
      : undefined,
  };
}

// Generate next-N-days date options for booking.
export function nextDays(count: number): Date[] {
  const out: Date[] = [];
  const now = new Date();
  for (let i = 0; i < count; i++) {
    const d = new Date(now);
    d.setDate(now.getDate() + i);
    d.setHours(0, 0, 0, 0);
    out.push(d);
  }
  return out;
}

// Time slots for a booking day.
export function timeSlots(): string[] {
  return [
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
  ];
}
