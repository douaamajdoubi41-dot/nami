"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  ReactNode,
} from "react";
import type { SessionUser, Lang } from "@/lib/types";
import { fetchMe, doLogin, doSignup, doLogout } from "@/lib/api-client";

interface AuthContextValue {
  user: SessionUser | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<SessionUser>;
  signup: (payload: {
    email: string;
    password: string;
    name: string;
    phone?: string;
    role: "PATIENT" | "HOSPITAL_ADMIN";
    language: Lang;
    hospitalName?: string;
    hospitalCity?: string;
    hospitalAddress?: string;
    hospitalType?: "PUBLIC" | "PRIVATE" | "CLINIC";
    hospitalPhone?: string;
  }) => Promise<SessionUser>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    fetchMe()
      .then((u) => {
        if (active) setUser(u);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const u = await doLogin(email, password);
    setUser(u);
    return u;
  }, []);

  const signup = useCallback(
    async (payload: Parameters<typeof doSignup>[0]) => {
      const u = await doSignup(payload);
      setUser(u);
      return u;
    },
    [],
  );

  const logout = useCallback(async () => {
    await doLogout();
    setUser(null);
  }, []);

  const refresh = useCallback(async () => {
    const u = await fetchMe();
    setUser(u);
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, login, signup, logout, refresh }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
