# Task 1 — full-stack-developer (video-service)

## Task
Built an independent Bun + TypeScript + Socket.io WebRTC signaling mini-service
for 1-to-1 video consultations between a patient and a doctor.

## Work Log
- Read `/home/z/my-project/worklog.md` to align with project conventions (emerald/teal theme, RTL i18n, SPA on `/`, video WS at `io('/?XTransformPort=3004')`).
- Inspected `examples/websocket/server.ts` for the established socket.io + Caddy pattern (path `/`, hardcoded port, graceful shutdown).
- Created `mini-services/video-service/` with `package.json` (name `sehati-video-service`, `type: module`, `dev: bun --hot index.ts`, `start: bun index.ts`, dep `socket.io@^4.8.1`).
- Created `tsconfig.json` (ES2022, ESNext modules, strict, noEmit — Bun runs TS directly).
- Created `index.ts`:
  - HTTP server on hardcoded port **3004**.
  - Socket.io with `path: '/'`, CORS `*`, `pingTimeout: 60000`, `pingInterval: 25000`.
  - Wrapped engine.io's request listener so `/health` is served directly (engine.io with `path: '/'` would otherwise intercept every URL and return 400 for non-engine.io requests).
  - Peer registry `Map<socket.id, { roomId, role, name }>`.
  - Events: `join-room`, `offer`, `answer`, `ice-candidate`, `toggle-media`, `end-call`, `disconnect` → emits `peer-joined`, `peer-ready`, `offer`, `answer`, `ice-candidate`, `toggle-media`, `end-call`, `peer-left`, `error`.
  - `uncaughtException` / `unhandledRejection` handlers so errors are logged instead of silently killing the process.
  - SIGTERM / SIGINT graceful shutdown (close io, then http, then exit 0).
- Ran `bun install` (installed socket.io@4.8.3, @types/node, typescript).
- Started with `nohup bun run dev &` (PID captured). Verified log line `Sehati video service listening on :3004`.
- Verified `curl http://localhost:3004/health` → `{"ok":true,"service":"sehati-video-service","port":3004}`.
- Smoke-tested the full signaling flow with a throwaway socket.io-client script (patient + doctor in same room): join-room → peer-joined → peer-ready → offer → ice-candidate → end-call → peer-left. All events relayed correctly. Removed the test script and the socket.io-client dev dep afterward (per "no test code" rule).

## Stage Summary
- **Location:** `/home/z/my-project/mini-services/video-service/`
- **Port:** 3004 (hardcoded, NOT from env)
- **Socket.io path:** `/` (REQUIRED for Caddy routing)
- **Frontend connection:** `io('/?XTransformPort=3004')` — relative path only, NEVER direct port.
- **Health endpoint:** `GET /health` → `{"ok":true,"service":"sehati-video-service","port":3004}` (HTTP 200, application/json).
- **Process:** started with `nohup bun run dev &`, PID see `pgrep -f "bun --hot index.ts"`. Log at `/tmp/video-service.log`.
- **Socket.io event names the frontend MUST use:**
  - Client → Server: `join-room` `{ roomId, role: "patient"|"doctor", name }`
  - Client → Server: `offer` `{ to: socketId, sdp }`
  - Client → Server: `answer` `{ to: socketId, sdp }`
  - Client → Server: `ice-candidate` `{ to: socketId, candidate }`
  - Client → Server: `toggle-media` `{ video: boolean, audio: boolean }`
  - Client → Server: `end-call` (no payload)
  - Server → Client: `peer-joined` `{ socketId, role, name }` — broadcast when a peer joins your room
  - Server → Client: `peer-ready` `{ socketId, role, name }` — sent to the joiner if a peer is already in the room (joiner should create the offer)
  - Server → Client: `offer` `{ from: socketId, sdp }`
  - Server → Client: `answer` `{ from: socketId, sdp }`
  - Server → Client: `ice-candidate` `{ from: socketId, candidate }`
  - Server → Client: `toggle-media` `{ socketId, video, audio }` — other peer's camera/mic state
  - Server → Client: `end-call` `{ from: socketId }`
  - Server → Client: `peer-left` `{ socketId, name }`
  - Server → Client: `error` `{ message }` — invalid join-room payload etc.
- **Typical 1-to-1 flow:**
  1. Patient `join-room` → server logs, patient waits.
  2. Doctor `join-room` → patient gets `peer-joined`, doctor gets `peer-ready` (with patient's socketId).
  3. Doctor creates RTCPeerConnection offer, emits `offer { to: patientSocketId, sdp }` → patient receives `offer { from: doctorSocketId, sdp }`.
  4. Patient sets remote, creates answer, emits `answer { to: doctorSocketId, sdp }` → doctor receives `answer`.
  5. Both exchange `ice-candidate { to, candidate }` until connected.
  6. Either side emits `toggle-media { video, audio }` to update UI indicators.
  7. Either side emits `end-call` → other receives `end-call`; on socket disconnect the other receives `peer-left`.
